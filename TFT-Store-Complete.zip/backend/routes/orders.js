// routes/orders.js
const express = require('express');
const router  = express.Router();
const Order   = require('../models/Order');
const Product = require('../models/Product');
const { protect, sellerOnly } = require('../middleware/auth');

// POST /api/orders - place order
router.post('/', protect, async (req, res) => {
  try {
    const { productId, size, qty = 1, address } = req.body;

    const product = await Product.findById(productId);
    if (!product) return res.status(404).json({ message: 'Product not found' });
    if (product.stock < qty) return res.status(400).json({ message: 'Out of stock' });

    const price       = product.price * qty;
    const commission  = Math.round(price * 0.04);
    const sellerPayout = price - commission;
    const orderId     = 'TFT-' + Math.random().toString(36).substr(2, 8).toUpperCase();

    const order = await Order.create({
      buyer: req.user.id,
      seller: product.seller,
      product: productId,
      size, qty, price,
      address, orderId,
      commission, sellerPayout,
      status: 'pending_confirmation'
    });

    res.status(201).json({ success: true, order });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/orders/my - buyer sees own orders
router.get('/my', protect, async (req, res) => {
  try {
    const orders = await Order.find({ buyer: req.user.id })
      .populate('product', 'name price images')
      .populate('seller', 'name shopName')
      .sort({ createdAt: -1 });
    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/orders/:id - single order detail
router.get('/:id', protect, async (req, res) => {
  try {
    const order = await Order.findOne({
      $or: [{ orderId: req.params.id }, { _id: req.params.id }]
    })
      .populate('product')
      .populate('buyer', 'name mobile')
      .populate('seller', 'name shopName upiId');

    if (!order) return res.status(404).json({ message: 'Order not found' });
    res.json({ success: true, order });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/orders/:id/status - seller updates status
router.put('/:id/status', protect, sellerOnly, async (req, res) => {
  try {
    const { status, trackingNumber, trackingUrl } = req.body;
    const order = await Order.findOneAndUpdate(
      { _id: req.params.id, seller: req.user.id },
      { status, trackingNumber, trackingUrl },
      { new: true }
    );
    if (!order) return res.status(404).json({ message: 'Order not found' });
    res.json({ success: true, order });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
