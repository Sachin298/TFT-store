// routes/auth.js
const express = require('express');
const router  = express.Router();
const jwt     = require('jsonwebtoken');
const User    = require('../models/User');
const { protect } = require('../middleware/auth');

const genToken = (user) => jwt.sign(
  { id: user._id, role: user.role },
  process.env.JWT_SECRET,
  { expiresIn: '30d' }
);

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, mobile, password, role, shopName, upiId, bankAccount, bankIFSC } = req.body;

    if (await User.findOne({ mobile }))
      return res.status(400).json({ message: 'Mobile already registered' });

    const user = await User.create({ name, mobile, password, role, shopName, upiId, bankAccount, bankIFSC });

    res.status(201).json({
      success: true,
      token: genToken(user),
      user: { id: user._id, name: user.name, mobile: user.mobile, role: user.role }
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { mobile, password } = req.body;
    const user = await User.findOne({ mobile });

    if (!user || !(await user.comparePassword(password)))
      return res.status(400).json({ message: 'Invalid credentials' });

    res.json({
      success: true,
      token: genToken(user),
      user: { id: user._id, name: user.name, mobile: user.mobile, role: user.role }
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/auth/me
router.get('/me', protect, async (req, res) => {
  const user = await User.findById(req.user.id).select('-password');
  res.json({ success: true, user });
});

// POST /api/auth/add-address
router.post('/add-address', protect, async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { $push: { addresses: req.body } },
      { new: true }
    ).select('-password');
    res.json({ success: true, addresses: user.addresses });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/auth/wishlist/:productId
router.post('/wishlist/:productId', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    const pid  = req.params.productId;
    const inWishlist = user.wishlist.includes(pid);

    if (inWishlist) user.wishlist.pull(pid);
    else user.wishlist.push(pid);

    await user.save();
    res.json({ success: true, inWishlist: !inWishlist });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
