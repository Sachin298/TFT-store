// routes/payment.js
const express   = require('express');
const router    = express.Router();
const Razorpay  = require('razorpay');
const crypto    = require('crypto');
const { protect } = require('../middleware/auth');
const Order     = require('../models/Order');

const razorpay = new Razorpay({
  key_id:     process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

// ── Helper: verify Razorpay signature ──────────────────────
const verifySignature = (orderId, paymentId, signature) => {
  const body     = orderId + '|' + paymentId;
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(body).digest('hex');
  return expected === signature;
};

// ── POST /api/payment/create-confirmation-fee ───────────────
// Step 1: Create ₹12 Razorpay order
router.post('/create-confirmation-fee', protect, async (req, res) => {
  try {
    const { orderId } = req.body;
    const order = await Order.findOne({ orderId });

    if (!order) return res.status(404).json({ message: 'Order not found' });
    if (order.confirmationFeePaid) return res.status(400).json({ message: 'Fee already paid' });

    const rzpOrder = await razorpay.orders.create({
      amount:   1200, // ₹12 in paise
      currency: 'INR',
      receipt:  `confirm_${orderId}`,
      notes:    { type: 'confirmation_fee', orderId, buyerId: req.user.id }
    });

    res.json({
      success:         true,
      razorpayOrderId: rzpOrder.id,
      amount:          rzpOrder.amount,
      currency:        rzpOrder.currency,
      key:             process.env.RAZORPAY_KEY_ID,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── POST /api/payment/verify-confirmation-fee ───────────────
// Step 2: Verify ₹12 payment → confirm order
router.post('/verify-confirmation-fee', protect, async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderId } = req.body;

    if (!verifySignature(razorpay_order_id, razorpay_payment_id, razorpay_signature))
      return res.status(400).json({ message: 'Payment verification failed' });

    const order = await Order.findOneAndUpdate(
      { orderId },
      {
        confirmationFeePaid:   true,
        confirmationPaymentId: razorpay_payment_id,
        razorpayOrderId:       razorpay_order_id,
        status:                'confirmed',
      },
      { new: true }
    );

    res.json({ success: true, message: '✅ Order Confirmed!', order });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── POST /api/payment/create-product-payment ───────────────
// Step 3: Create Razorpay order for product price
router.post('/create-product-payment', protect, async (req, res) => {
  try {
    const { orderId } = req.body;
    const order = await Order.findOne({ orderId });

    if (!order) return res.status(404).json({ message: 'Order not found' });
    if (!order.confirmationFeePaid) return res.status(400).json({ message: 'Pay ₹12 fee first' });

    const totalPaise = (order.price + order.shipping) * 100;

    const rzpOrder = await razorpay.orders.create({
      amount:   totalPaise,
      currency: 'INR',
      receipt:  `product_${orderId}`,
      notes:    {
        type:       'product_payment',
        orderId,
        commission: order.commission,
        sellerPayout: order.sellerPayout,
      }
    });

    res.json({
      success:         true,
      razorpayOrderId: rzpOrder.id,
      amount:          rzpOrder.amount,
      currency:        rzpOrder.currency,
      key:             process.env.RAZORPAY_KEY_ID,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── POST /api/payment/verify-product-payment ───────────────
// Step 4: Verify product payment → update order
router.post('/verify-product-payment', protect, async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderId } = req.body;

    if (!verifySignature(razorpay_order_id, razorpay_payment_id, razorpay_signature))
      return res.status(400).json({ message: 'Payment verification failed' });

    const order = await Order.findOneAndUpdate(
      { orderId },
      { productPaymentId: razorpay_payment_id, status: 'packed' },
      { new: true }
    );

    // NOTE: Seller payout via Razorpay Route will go here
    // Requires Razorpay Route feature (after KYC activation)
    // razorpay.transfers.create({ account: sellerRazorpayId, amount: order.sellerPayout * 100 })

    res.json({
      success: true,
      message: '✅ Payment successful! Order is being packed.',
      order,
      breakdown: {
        totalPaid:    order.price + order.shipping,
        tftEarned:    order.commission + 12, // 4% + ₹12 fee
        sellerPayout: order.sellerPayout,
      }
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── POST /api/payment/webhook ───────────────────────────────
// Razorpay webhook
router.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  try {
    const signature = req.headers['x-razorpay-signature'];
    const expected  = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(req.body.toString()).digest('hex');

    if (signature !== expected)
      return res.status(400).json({ message: 'Invalid webhook' });

    const event = JSON.parse(req.body.toString());
    console.log('📦 Webhook event:', event.event);

    res.json({ received: true });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
