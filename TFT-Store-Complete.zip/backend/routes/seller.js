// routes/seller.js
const express = require('express');
const router  = express.Router();
const Order   = require('../models/Order');
const Product = require('../models/Product');
const { protect, sellerOnly } = require('../middleware/auth');

// GET /api/seller/dashboard - seller stats
router.get('/dashboard', protect, sellerOnly, async (req, res) => {
  try {
    const sellerId = req.user.id;

    const orders = await Order.find({ seller: sellerId });
    const products = await Product.find({ seller: sellerId, isActive: true });

    const totalOrders    = orders.length;
    const confirmedOrders = orders.filter(o => o.status !== 'pending_confirmation').length;
    const deliveredOrders = orders.filter(o => o.status === 'delivered').length;
    const totalEarnings  = orders
      .filter(o => o.status === 'delivered')
      .reduce((sum, o) => sum + o.sellerPayout, 0);
    const pendingPayout  = orders
      .filter(o => ['confirmed','packed','shipped'].includes(o.status))
      .reduce((sum, o) => sum + o.sellerPayout, 0);

    res.json({
      success: true,
      stats: {
        totalProducts:  products.length,
        totalOrders,
        confirmedOrders,
        deliveredOrders,
        totalEarnings,
        pendingPayout,
      }
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/seller/orders - seller's all orders
router.get('/orders', protect, sellerOnly, async (req, res) => {
  try {
    const orders = await Order.find({ seller: req.user.id })
      .populate('product', 'name price images')
      .populate('buyer', 'name mobile')
      .sort({ createdAt: -1 });

    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/seller/products - seller's own products
router.get('/products', protect, sellerOnly, async (req, res) => {
  try {
    const products = await Product.find({ seller: req.user.id })
      .sort({ createdAt: -1 });
    res.json({ success: true, products });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/seller/earnings - earnings breakdown
router.get('/earnings', protect, sellerOnly, async (req, res) => {
  try {
    const orders = await Order.find({
      seller: req.user.id,
      status: 'delivered'
    }).populate('product', 'name');

    const earnings = orders.map(o => ({
      orderId:     o.orderId,
      product:     o.product?.name,
      salePrice:   o.price,
      commission:  o.commission,
      yourEarning: o.sellerPayout,
      date:        o.createdAt,
    }));

    const total = earnings.reduce((s, e) => s + e.yourEarning, 0);

    res.json({ success: true, total, earnings });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
