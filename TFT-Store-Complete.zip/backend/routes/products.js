// routes/products.js
const express = require('express');
const router  = express.Router();
const Product = require('../models/Product');
const { protect, sellerOnly } = require('../middleware/auth');

// GET /api/products
router.get('/', async (req, res) => {
  try {
    const { category, condition, minPrice, maxPrice, search, sort } = req.query;
    let query = { isActive: true };

    if (category && category !== 'All') query.category = category;
    if (condition && condition !== 'All') query.condition = condition;
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = +minPrice;
      if (maxPrice) query.price.$lte = +maxPrice;
    }
    if (search) {
      query.$or = [
        { name:  { $regex: search, $options: 'i' } },
        { brand: { $regex: search, $options: 'i' } }
      ];
    }

    const sortObj = sort === 'low' ? { price: 1 } : sort === 'high' ? { price: -1 } : sort === 'rating' ? { rating: -1 } : { createdAt: -1 };

    const products = await Product.find(query)
      .sort(sortObj)
      .populate('seller', 'name shopName city isVerified');

    res.json({ success: true, count: products.length, products });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/products/:id
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id)
      .populate('seller', 'name shopName city isVerified rating');
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json({ success: true, product });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/products - seller adds product
router.post('/', protect, sellerOnly, async (req, res) => {
  try {
    const product = await Product.create({ ...req.body, seller: req.user.id });
    res.status(201).json({ success: true, product });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/products/:id - seller edits
router.put('/:id', protect, sellerOnly, async (req, res) => {
  try {
    const product = await Product.findOneAndUpdate(
      { _id: req.params.id, seller: req.user.id },
      req.body,
      { new: true }
    );
    if (!product) return res.status(404).json({ message: 'Not found or not your product' });
    res.json({ success: true, product });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE /api/products/:id - seller removes
router.delete('/:id', protect, sellerOnly, async (req, res) => {
  try {
    await Product.findOneAndUpdate(
      { _id: req.params.id, seller: req.user.id },
      { isActive: false }
    );
    res.json({ success: true, message: 'Product removed' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
