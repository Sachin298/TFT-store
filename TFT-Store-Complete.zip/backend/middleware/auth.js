// middleware/auth.js
const jwt = require('jsonwebtoken');

const protect = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Not authorized' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ message: 'Invalid token' });
  }
};

const sellerOnly = (req, res, next) => {
  if (req.user.role !== 'seller')
    return res.status(403).json({ message: 'Sellers only' });
  next();
};

module.exports = { protect, sellerOnly };
