// models/User.js
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const UserSchema = new mongoose.Schema({
  name:     { type: String, required: true },
  mobile:   { type: String, required: true, unique: true },
  email:    { type: String },
  password: { type: String, required: true },
  role:     { type: String, enum: ['buyer', 'seller'], default: 'buyer' },

  // Seller only
  shopName:   { type: String },
  upiId:      { type: String },
  bankAccount:{ type: String },
  bankIFSC:   { type: String },
  isVerified: { type: Boolean, default: false },

  // Buyer only
  addresses: [{
    name: String, phone: String, address: String,
    city: String, state: String, pincode: String,
    type: { type: String, default: 'Home' }
  }],
  wishlist: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],

  createdAt: { type: Date, default: Date.now }
});

UserSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

UserSchema.methods.comparePassword = function(p) {
  return bcrypt.compare(p, this.password);
};

module.exports = mongoose.model('User', UserSchema);
