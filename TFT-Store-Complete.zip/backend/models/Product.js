// models/Product.js
const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
  seller:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name:      { type: String, required: true },
  brand:     { type: String },
  category:  { type: String, required: true, enum: ['Women','Men','Kids','Footwear','Accessories','Winter Wear'] },
  condition: { type: String, required: true, enum: ['Like New','Good','Fair'] },
  price:     { type: Number, required: true },
  original:  { type: Number },
  sizes:     [String],
  stock:     { type: Number, default: 1 },
  desc:      { type: String },
  highlights:[String],
  images:    [String],
  rating:    { type: Number, default: 0 },
  numReviews:{ type: Number, default: 0 },
  isActive:  { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Product', ProductSchema);
