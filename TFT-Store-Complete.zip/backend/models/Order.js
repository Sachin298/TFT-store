// models/Order.js
const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  buyer:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  seller:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },

  size:     String,
  qty:      { type: Number, default: 1 },
  price:    Number,
  shipping: { type: Number, default: 40 },

  address: {
    name: String, phone: String, address: String,
    city: String, state: String, pincode: String,
  },

  // Payments
  confirmationFeePaid:   { type: Boolean, default: false },
  confirmationPaymentId: String,
  productPaymentId:      String,
  razorpayOrderId:       String,

  // Money split
  commission:   Number, // 4%
  sellerPayout: Number, // 96%

  // Status
  status: {
    type: String,
    enum: ['pending_confirmation','confirmed','packed','shipped','delivered','cancelled'],
    default: 'pending_confirmation'
  },

  // Shiprocket
  shiprocketOrderId:    String,
  trackingNumber:       String,
  trackingUrl:          String,

  orderId:   { type: String, unique: true }, // e.g. TFT-ABC123
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Order', OrderSchema);
