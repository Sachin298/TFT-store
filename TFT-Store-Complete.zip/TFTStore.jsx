import { useState, useEffect } from "react";

const PRODUCTS = [
  { id:1,  name:"Floral Kurta Set",        brand:"Fabindia",   price:199,  original:899,  condition:"Like New", category:"Women",   emoji:"👗", seller:"Priya NGO",         city:"Delhi",    rating:4.5, reviews:128, sizes:["XS","S","M","L","XL"],     desc:"Beautiful floral print kurta set. Worn only twice. Comes with dupatta.", highlights:["100% Cotton","Includes dupatta","Lightly used"] },
  { id:2,  name:"Levi's Denim Jacket",     brand:"Levi's",     price:599,  original:2499, condition:"Good",     category:"Men",     emoji:"🧥", seller:"Rahul Thrift",      city:"Mumbai",   rating:4.8, reviews:214, sizes:["S","M","L","XL","XXL"],    desc:"Authentic Levi's denim jacket. Vintage fade look.", highlights:["100% Denim","Original tag","Machine washable"] },
  { id:3,  name:"Kids Winter Coat",        brand:"H&M",        price:149,  original:599,  condition:"Good",     category:"Kids",    emoji:"🧒", seller:"Helping Hands NGO", city:"Pune",     rating:4.2, reviews:67,  sizes:["3-4Y","5-6Y","7-8Y"],      desc:"Warm kids winter coat. No tears or stains.", highlights:["Polyester fill","Hood included","No stains"] },
  { id:4,  name:"Leather Ankle Boots",     brand:"Clarks",     price:399,  original:1799, condition:"Fair",     category:"Footwear",emoji:"👢", seller:"Meena Fashion",     city:"Pune",     rating:4.0, reviews:43,  sizes:["36","37","38","39","40"],  desc:"Clarks leather ankle boots. Minor scratches.", highlights:["Genuine leather","Side zip"] },
  { id:5,  name:"Woolen Pashmina Shawl",   brand:"Pashmina",   price:249,  original:899,  condition:"Like New", category:"Women",   emoji:"🧣", seller:"Rita Devi",         city:"Jaipur",   rating:4.7, reviews:89,  sizes:["Free Size"],               desc:"Pure woolen pashmina shawl. Never used.", highlights:["Pure wool","Never used","Very soft"] },
  { id:6,  name:"Van Heusen Formal Shirt", brand:"Van Heusen", price:129,  original:499,  condition:"Good",     category:"Men",     emoji:"👔", seller:"Old is Gold NGO",   city:"Hyderabad",rating:4.3, reviews:55,  sizes:["S","M","L","XL"],          desc:"Van Heusen formal shirt. Washed and ironed.", highlights:["Cotton blend","All buttons intact"] },
  { id:7,  name:"Biba Salwar Kameez",      brand:"Biba",       price:179,  original:699,  condition:"Good",     category:"Women",   emoji:"👘", seller:"Anita Boutique",    city:"Lucknow",  rating:4.6, reviews:102, sizes:["XS","S","M","L"],          desc:"Biba printed salwar kameez full set.", highlights:["Full set","Vibrant colors"] },
  { id:8,  name:"Woodland Sneakers",       brand:"Woodland",   price:299,  original:1199, condition:"Fair",     category:"Footwear",emoji:"👟", seller:"Thrift Hub",        city:"Delhi",    rating:4.1, reviews:38,  sizes:["7","8","9","10","11"],     desc:"Woodland canvas sneakers. New laces.", highlights:["Canvas upper","New laces","Cleaned"] },
  { id:9,  name:"Adidas Sports Jacket",    brand:"Adidas",     price:449,  original:1999, condition:"Like New", category:"Men",     emoji:"🏃", seller:"SportThrift",       city:"Mumbai",   rating:4.9, reviews:176, sizes:["S","M","L","XL"],          desc:"Adidas sports jacket. Worn once.", highlights:["Worn once","Zip pockets"] },
  { id:10, name:"W Ethnic Kurta Set",      brand:"W",          price:219,  original:999,  condition:"Like New", category:"Women",   emoji:"🥻", seller:"Priya NGO",         city:"Delhi",    rating:4.6, reviews:94,  sizes:["XS","S","M","L","XL","XXL"],desc:"W for Woman kurta with palazzo.", highlights:["Embroidered neck","Palazzo included"] },
  { id:11, name:"Nike Running Shoes",      brand:"Nike",       price:699,  original:3499, condition:"Good",     category:"Footwear",emoji:"👠", seller:"SportThrift",       city:"Mumbai",   rating:4.7, reviews:203, sizes:["6","7","8","9","10"],      desc:"Nike running shoes. Gym use only.", highlights:["Air cushion","Good grip"] },
  { id:12, name:"Kids Denim Jeans",        brand:"Zara Kids",  price:99,   original:599,  condition:"Good",     category:"Kids",    emoji:"👖", seller:"Helping Hands NGO", city:"Pune",     rating:4.4, reviews:29,  sizes:["4-5Y","6-7Y","8-9Y"],      desc:"Zara Kids denim jeans. Elastic waistband.", highlights:["Elastic waist","Dark blue"] },
];

const SELLER_ORDERS = [
  { id:"TFT-A8X2K1", product:"Floral Kurta Set",  buyer:"Anita S.", city:"Delhi",  price:199, status:"delivered", date:"12 May 2026" },
  { id:"TFT-B3M7P2", product:"W Ethnic Kurta Set", buyer:"Priya R.", city:"Mumbai", price:219, status:"shipped",   date:"15 May 2026" },
  { id:"TFT-C9K4L3", product:"Woolen Shawl",       buyer:"Meera T.", city:"Jaipur", price:249, status:"confirmed", date:"16 May 2026" },
  { id:"TFT-D2N8Q4", product:"Floral Kurta Set",   buyer:"Sunita K.",city:"Pune",   price:199, status:"packed",    date:"17 May 2026" },
];

const CATS = ["All","Women","Men","Kids","Footwear"];
const condStyle   = { "Like New":["#dbeafe","#1e40af"], "Good":["#dcfce7","#166534"], "Fair":["#fef9c3","#a16207"] };
const statusStyle = { confirmed:["#dbeafe","#1e40af"], packed:["#fef9c3","#a16207"], shipped:["#e0f2fe","#0369a1"], delivered:["#dcfce7","#166534"] };
const BG = ["#EFF6FF","#F0FDF4","#FFF7ED","#FAF5FF","#F0F9FF","#FDF4FF","#ECFDF5","#FFF1F2"];
const C = { blue:"#2563eb", dk:"#1d4ed8", lt:"#eff6ff", bd:"#bfdbfe", org:"#f97316", grn:"#16a34a", red:"#ef4444", g50:"#f8fafc", g100:"#f1f5f9", g200:"#e2e8f0", g400:"#94a3b8", g600:"#475569", g900:"#0f172a", wh:"#fff" };

function Stars({n}){ return <span style={{color:"#f59e0b",fontSize:"0.78rem"}}>{"★".repeat(Math.floor(n))}{"☆".repeat(5-Math.floor(n))}</span>; }

function Header({mode,setMode,cartCount,wishCount,search,setSearch,onCart,onLogo,onLogin,user,onLogout}){
  return (
    <header style={{position:"sticky",top:0,zIndex:300,boxShadow:"0 2px 12px rgba(0,0,0,0.15)"}}>
      <div style={{background:C.blue,height:56,display:"flex",alignItems:"center",padding:"0 24px",gap:16}}>
        <div onClick={onLogo} style={{cursor:"pointer",display:"flex",alignItems:"center",gap:8,flexShrink:0}}>
          <div style={{background:C.wh,borderRadius:6,width:32,height:32,display:"flex",alignItems:"center",justifyContent:"center"}}>♻️</div>
          <span style={{fontFamily:"Georgia,serif",fontSize:"1.3rem",fontWeight:900,color:C.wh}}>TFT</span>
          <span style={{fontFamily:"Georgia,serif",fontSize:"1.3rem",color:"#bfdbfe"}}> Store</span>
        </div>
        <div style={{flex:1,display:"flex",maxWidth:560}}>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search clothes, brands..." style={{flex:1,height:38,padding:"0 16px",border:"none",borderRadius:"6px 0 0 6px",fontSize:"0.88rem",outline:"none",fontFamily:"inherit"}} />
          <button style={{width:46,height:38,background:C.org,border:"none",borderRadius:"0 6px 6px 0",cursor:"pointer",fontSize:"1.1rem"}}>🔍</button>
        </div>
        <div style={{display:"flex",gap:16,alignItems:"center",marginLeft:"auto",flexShrink:0}}>
          <div style={{display:"flex",background:"rgba(255,255,255,0.15)",borderRadius:20,padding:3,gap:2}}>
            {["customer","seller"].map(m=>(
              <button key={m} onClick={()=>setMode(m)} style={{padding:"5px 14px",borderRadius:16,border:"none",background:mode===m?C.wh:"transparent",color:mode===m?C.blue:C.wh,fontWeight:700,cursor:"pointer",fontSize:"0.76rem",fontFamily:"inherit",transition:"all 0.2s"}}>
                {m==="customer"?"🛍️ Customer":"🏪 Seller"}
              </button>
            ))}
          </div>
          {user
            ? <><span style={{color:C.wh,fontSize:"0.84rem",fontWeight:600}}>Hi, {user}!</span><span onClick={onLogout} style={{color:"#bfdbfe",fontSize:"0.8rem",cursor:"pointer"}}>Logout</span></>
            : <span onClick={onLogin} style={{color:C.wh,fontSize:"0.84rem",cursor:"pointer",fontWeight:600,background:"rgba(255,255,255,0.2)",padding:"6px 14px",borderRadius:20}}>Login / Register</span>
          }
          {mode==="customer" && <>
            <span style={{color:C.wh,cursor:"pointer",fontSize:"0.84rem"}}>❤️ {wishCount}</span>
            <div onClick={onCart} style={{position:"relative",color:C.wh,cursor:"pointer",display:"flex",alignItems:"center",gap:5}}>
              <span style={{fontSize:"1.3rem"}}>🛒</span>
              <span style={{fontSize:"0.84rem",fontWeight:700}}>Cart</span>
              {cartCount>0&&<span style={{position:"absolute",top:-8,right:-8,background:C.org,borderRadius:"50%",width:18,height:18,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"0.62rem",fontWeight:700}}>{cartCount}</span>}
            </div>
          </>}
        </div>
      </div>
      {mode==="customer"&&(
        <div style={{background:C.dk,display:"flex",padding:"0 24px",gap:0}}>
          {[...CATS,"Winter Wear","Accessories"].map(c=><span key={c} style={{color:"#e0f2fe",fontSize:"0.8rem",padding:"7px 16px",cursor:"pointer",whiteSpace:"nowrap"}}>{c}</span>)}
          <span style={{color:"#fbbf24",fontSize:"0.8rem",padding:"7px 16px",cursor:"pointer",fontWeight:700,marginLeft:"auto"}}>🔥 Best Deals</span>
        </div>
      )}
    </header>
  );
}

function PCard({p,i,onView,onWish,wished,onCart}){
  const [h,setH]=useState(false);
  const disc=Math.round((1-p.price/p.original)*100);
  return (
    <div onClick={()=>onView(p)} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
      style={{background:C.wh,cursor:"pointer",border:"1px solid "+(h?C.bd:C.g200),transition:"all 0.2s",boxShadow:h?"0 8px 24px rgba(37,99,235,0.12)":"0 1px 4px rgba(0,0,0,0.05)",transform:h?"translateY(-3px)":"none",borderRadius:8,overflow:"hidden",position:"relative"}}>
      <button onClick={e=>{e.stopPropagation();onWish(p.id);}} style={{position:"absolute",top:8,right:8,background:"rgba(255,255,255,0.92)",border:"1px solid "+C.g200,borderRadius:"50%",width:30,height:30,cursor:"pointer",fontSize:"0.9rem",zIndex:1,display:"flex",alignItems:"center",justifyContent:"center"}}>
        {wished?"❤️":"🤍"}
      </button>
      <div style={{height:190,background:BG[i%BG.length],display:"flex",alignItems:"center",justifyContent:"center",fontSize:"3.5rem"}}>{p.emoji}</div>
      <div style={{padding:"10px 12px 14px"}}>
        <div style={{fontSize:"0.7rem",color:C.g400,marginBottom:2}}>{p.brand}</div>
        <div style={{fontSize:"0.87rem",fontWeight:600,color:C.g900,marginBottom:4,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical",lineHeight:1.3}}>{p.name}</div>
        <div style={{display:"flex",alignItems:"center",gap:4,marginBottom:5}}>
          <span style={{background:C.grn,color:C.wh,fontSize:"0.68rem",padding:"2px 5px",borderRadius:2,fontWeight:700}}>{p.rating}★</span>
          <span style={{color:C.g400,fontSize:"0.7rem"}}>({p.reviews})</span>
        </div>
        <div style={{display:"flex",alignItems:"baseline",gap:5,marginBottom:6}}>
          <span style={{fontSize:"1.05rem",fontWeight:800,color:C.g900}}>₹{p.price}</span>
          <span style={{fontSize:"0.74rem",color:C.g400,textDecoration:"line-through"}}>₹{p.original}</span>
          <span style={{fontSize:"0.7rem",color:C.grn,fontWeight:700}}>{disc}% off</span>
        </div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <span style={{fontSize:"0.67rem",padding:"2px 7px",borderRadius:3,background:condStyle[p.condition][0],color:condStyle[p.condition][1],fontWeight:700}}>{p.condition}</span>
          <button onClick={e=>{e.stopPropagation();onCart(p);}} style={{background:C.blue,color:C.wh,border:"none",borderRadius:5,padding:"5px 12px",fontSize:"0.74rem",fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>+ Cart</button>
        </div>
      </div>
    </div>
  );
}

function Home({search,onView,wish,onWish,onCart}){
  const [cat,setCat]=useState("All");
  const [cond,setCond]=useState("All");
  const [max,setMax]=useState(2000);
  const [sort,setSort]=useState("default");
  const list=PRODUCTS.filter(p=>(cat==="All"||p.category===cat)&&(cond==="All"||p.condition===cond)&&p.price<=max&&(p.name.toLowerCase().includes(search.toLowerCase())||p.brand.toLowerCase().includes(search.toLowerCase()))).sort((a,b)=>sort==="low"?a.price-b.price:sort==="high"?b.price-a.price:sort==="rating"?b.rating-a.rating:0);
  return (
    <div style={{maxWidth:1300,margin:"0 auto",padding:"16px 20px",display:"flex",gap:16,alignItems:"flex-start"}}>
      <div style={{width:205,flexShrink:0,background:C.wh,borderRadius:8,padding:16,boxShadow:"0 1px 4px rgba(0,0,0,0.07)",position:"sticky",top:108}}>
        <div style={{fontWeight:800,fontSize:"0.9rem",marginBottom:14,paddingBottom:8,borderBottom:"1px solid "+C.g100}}>🔽 Filters</div>
        <div style={{marginBottom:14}}>
          <div style={{fontWeight:700,fontSize:"0.73rem",marginBottom:7,color:C.g600,textTransform:"uppercase",letterSpacing:0.5}}>Category</div>
          {CATS.map(c=><label key={c} style={{display:"flex",alignItems:"center",gap:7,marginBottom:5,cursor:"pointer",fontSize:"0.83rem",color:cat===c?C.blue:C.g600,fontWeight:cat===c?700:400}}><input type="radio" name="cat" checked={cat===c} onChange={()=>setCat(c)} style={{accentColor:C.blue}} />{c}</label>)}
        </div>
        <div style={{marginBottom:14,paddingTop:10,borderTop:"1px solid "+C.g100}}>
          <div style={{fontWeight:700,fontSize:"0.73rem",marginBottom:7,color:C.g600,textTransform:"uppercase"}}>Price Range</div>
          <input type="range" min={99} max={2000} value={max} onChange={e=>setMax(+e.target.value)} style={{width:"100%",accentColor:C.blue,marginBottom:4}} />
          <div style={{display:"flex",justifyContent:"space-between",fontSize:"0.75rem",color:C.g400}}><span>₹99</span><span style={{color:C.blue,fontWeight:700}}>₹{max}</span></div>
        </div>
        <div style={{marginBottom:14,paddingTop:10,borderTop:"1px solid "+C.g100}}>
          <div style={{fontWeight:700,fontSize:"0.73rem",marginBottom:7,color:C.g600,textTransform:"uppercase"}}>Condition</div>
          {["All","Like New","Good","Fair"].map(c=><label key={c} style={{display:"flex",alignItems:"center",gap:7,marginBottom:5,cursor:"pointer",fontSize:"0.83rem",color:cond===c?C.blue:C.g600,fontWeight:cond===c?700:400}}><input type="radio" name="cond" checked={cond===c} onChange={()=>setCond(c)} style={{accentColor:C.blue}} />{c}</label>)}
        </div>
        <div style={{paddingTop:10,borderTop:"1px solid "+C.g100}}>
          <div style={{fontWeight:700,fontSize:"0.73rem",marginBottom:7,color:C.g600,textTransform:"uppercase"}}>Sort By</div>
          <select value={sort} onChange={e=>setSort(e.target.value)} style={{width:"100%",padding:"7px 8px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.81rem",fontFamily:"inherit"}}>
            <option value="default">Relevance</option>
            <option value="low">Price: Low to High</option>
            <option value="high">Price: High to Low</option>
            <option value="rating">Top Rated</option>
          </select>
        </div>
      </div>
      <div style={{flex:1}}>
        <div style={{background:"linear-gradient(135deg,#1d4ed8,#2563eb,#3b82f6)",borderRadius:10,padding:"22px 28px",marginBottom:14,color:C.wh,display:"flex",justifyContent:"space-between",alignItems:"center",position:"relative",overflow:"hidden"}}>
          <div style={{position:"absolute",right:-30,top:-30,width:180,height:180,borderRadius:"50%",background:"rgba(255,255,255,0.05)"}} />
          <div>
            <div style={{fontSize:"0.7rem",fontWeight:700,letterSpacing:2,textTransform:"uppercase",opacity:0.8,marginBottom:6}}>♻️ Thrift For Tomorrow</div>
            <div style={{fontSize:"1.5rem",fontWeight:900,lineHeight:1.2}}>India Ka Apna<br/><span style={{color:"#bfdbfe"}}>Thrift Marketplace</span></div>
            <div style={{fontSize:"0.83rem",opacity:0.8,marginTop:4}}>Pre-loved fashion — up to 90% off</div>
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{fontSize:"2.5rem",fontWeight:900}}>{list.length}</div>
            <div style={{fontSize:"0.76rem",opacity:0.8}}>items available</div>
          </div>
        </div>
        {list.length===0
          ? <div style={{background:C.wh,borderRadius:8,padding:"4rem",textAlign:"center",color:C.g400}}><div style={{fontSize:"3rem",marginBottom:10}}>🔍</div><div style={{fontWeight:700}}>No items found</div></div>
          : <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(195px,1fr))",gap:12}}>
              {list.map((p,i)=><PCard key={p.id} p={p} i={i} onView={onView} onWish={onWish} wished={wish.includes(p.id)} onCart={onCart} />)}
            </div>
        }
      </div>
    </div>
  );
}

function Detail({p,onBack,onCart,onBuy,onWish,wished}){
  const [size,setSize]=useState(""); const [qty,setQty]=useState(1); const [tab,setTab]=useState("desc"); const [err,setErr]=useState(false);
  const disc=Math.round((1-p.price/p.original)*100);
  const go=fn=>{if(!size){setErr(true);return;} setErr(false); fn({...p,selSize:size,qty});};
  return (
    <div style={{maxWidth:1200,margin:"0 auto",padding:"16px 20px"}}>
      <div style={{fontSize:"0.77rem",color:C.g400,marginBottom:12,display:"flex",gap:6}}>
        <span onClick={onBack} style={{cursor:"pointer",color:C.blue,fontWeight:600}}>← Home</span>
        <span>›</span><span onClick={onBack} style={{cursor:"pointer",color:C.blue}}>{p.category}</span>
        <span>›</span><span>{p.name}</span>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20,background:C.wh,borderRadius:10,padding:24,boxShadow:"0 2px 12px rgba(0,0,0,0.07)",marginBottom:14}}>
        <div>
          <div style={{background:BG[p.id%BG.length],borderRadius:8,height:370,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"7.5rem",position:"relative",border:"1px solid "+C.g200}}>
            {p.emoji}
            <button onClick={()=>onWish(p.id)} style={{position:"absolute",top:12,right:12,background:C.wh,border:"1px solid "+C.g200,borderRadius:"50%",width:36,height:36,cursor:"pointer",fontSize:"1.1rem",display:"flex",alignItems:"center",justifyContent:"center"}}>{wished?"❤️":"🤍"}</button>
          </div>
          <div style={{display:"flex",gap:8,marginTop:10}}>
            {[p.emoji,"📦","✨"].map((e,i)=><div key={i} style={{width:60,height:60,background:BG[(p.id+i)%BG.length],borderRadius:6,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.7rem",border:"2px solid "+(i===0?C.blue:C.g200),cursor:"pointer"}}>{e}</div>)}
          </div>
        </div>
        <div>
          <div style={{fontSize:"0.74rem",color:C.g400,marginBottom:3}}>{p.brand}</div>
          <h1 style={{fontSize:"1.3rem",fontWeight:700,color:C.g900,marginBottom:10,lineHeight:1.3}}>{p.name}</h1>
          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:14,paddingBottom:14,borderBottom:"1px solid "+C.g100}}>
            <span style={{background:C.grn,color:C.wh,fontSize:"0.77rem",padding:"3px 8px",borderRadius:3,fontWeight:700}}>{p.rating} ★</span>
            <span style={{color:C.g400,fontSize:"0.81rem"}}>{p.reviews.toLocaleString()} ratings</span>
          </div>
          <div style={{marginBottom:14}}>
            <span style={{fontSize:"2rem",fontWeight:900,color:C.g900}}>₹{p.price}</span>
            <span style={{fontSize:"0.94rem",color:C.g400,textDecoration:"line-through",marginLeft:10}}>₹{p.original}</span>
            <span style={{fontSize:"0.88rem",color:C.grn,marginLeft:8,fontWeight:700}}>{disc}% off</span>
            <div style={{fontSize:"0.75rem",color:C.g400,marginTop:3}}>Inclusive of all taxes</div>
          </div>
          <div style={{marginBottom:14,display:"flex",alignItems:"center",gap:8}}>
            <span style={{fontSize:"0.81rem",fontWeight:600,color:C.g600}}>Condition:</span>
            <span style={{fontSize:"0.79rem",padding:"3px 12px",borderRadius:3,background:condStyle[p.condition][0],color:condStyle[p.condition][1],fontWeight:700}}>{p.condition}</span>
          </div>
          <div style={{marginBottom:16}}>
            <div style={{fontSize:"0.81rem",fontWeight:700,marginBottom:8,color:C.g900}}>Select Size {err&&<span style={{color:C.red,fontWeight:400,fontSize:"0.76rem"}}>— Please select!</span>}</div>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {p.sizes.map(s=><button key={s} onClick={()=>{setSize(s);setErr(false);}} style={{padding:"8px 14px",border:size===s?"2px solid "+C.blue:"1.5px solid "+C.g200,borderRadius:5,background:size===s?C.lt:C.wh,color:size===s?C.blue:C.g600,fontWeight:size===s?700:400,cursor:"pointer",fontFamily:"inherit",fontSize:"0.84rem",transition:"all 0.15s"}}>{s}</button>)}
            </div>
          </div>
          <div style={{marginBottom:20,display:"flex",alignItems:"center",gap:12}}>
            <span style={{fontSize:"0.81rem",fontWeight:700,color:C.g900}}>Qty:</span>
            <div style={{display:"flex",alignItems:"center",border:"1px solid "+C.g200,borderRadius:5,overflow:"hidden"}}>
              <button onClick={()=>setQty(q=>Math.max(1,q-1))} style={{width:33,height:33,border:"none",background:C.g100,cursor:"pointer",fontWeight:700,fontSize:"1.1rem"}}>−</button>
              <span style={{width:40,textAlign:"center",fontWeight:700}}>{qty}</span>
              <button onClick={()=>setQty(q=>q+1)} style={{width:33,height:33,border:"none",background:C.g100,cursor:"pointer",fontWeight:700,fontSize:"1.1rem"}}>+</button>
            </div>
          </div>
          <div style={{display:"flex",gap:10,marginBottom:16}}>
            <button onClick={()=>go(onCart)} style={{flex:1,padding:"13px",background:"#fff7ed",border:"2px solid "+C.org,color:"#ea580c",borderRadius:6,fontWeight:800,cursor:"pointer",fontSize:"0.93rem",fontFamily:"inherit"}}>🛒 Add to Cart</button>
            <button onClick={()=>go(onBuy)} style={{flex:1,padding:"13px",background:C.org,border:"none",color:C.wh,borderRadius:6,fontWeight:800,cursor:"pointer",fontSize:"0.93rem",fontFamily:"inherit"}}>⚡ Buy Now</button>
          </div>
          <div style={{background:C.g50,borderRadius:6,padding:"12px 14px",border:"1px solid "+C.g200}}>
            <div style={{fontSize:"0.79rem",marginBottom:4}}><span style={{fontWeight:700,color:C.g900}}>Sold by:</span> <span style={{color:C.blue,fontWeight:600}}>{p.seller}</span> <span style={{background:C.grn,color:C.wh,fontSize:"0.65rem",padding:"2px 6px",borderRadius:2,marginLeft:6,fontWeight:700}}>✓ Verified</span></div>
            <div style={{fontSize:"0.75rem",color:C.g400}}>📍 {p.city} &nbsp;|&nbsp; 🚚 Shiprocket Delivery · ₹40</div>
          </div>
        </div>
      </div>
      <div style={{background:C.wh,borderRadius:8,boxShadow:"0 1px 4px rgba(0,0,0,0.07)",overflow:"hidden"}}>
        <div style={{display:"flex",borderBottom:"1px solid "+C.g200}}>
          {[["desc","Description"],["highlights","Highlights"],["reviews","Reviews ("+p.reviews+")"]].map(([k,l])=><button key={k} onClick={()=>setTab(k)} style={{padding:"13px 22px",border:"none",background:"none",cursor:"pointer",fontFamily:"inherit",fontSize:"0.86rem",fontWeight:tab===k?700:500,color:tab===k?C.blue:C.g400,borderBottom:tab===k?"2px solid "+C.blue:"2px solid transparent"}}>{l}</button>)}
        </div>
        <div style={{padding:20}}>
          {tab==="desc"&&<p style={{fontSize:"0.88rem",color:C.g600,lineHeight:1.8}}>{p.desc}</p>}
          {tab==="highlights"&&<ul style={{paddingLeft:20}}>{p.highlights.map((h,i)=><li key={i} style={{fontSize:"0.88rem",color:C.g600,marginBottom:8}}>✅ {h}</li>)}</ul>}
          {tab==="reviews"&&<div>
            <div style={{display:"flex",alignItems:"center",gap:16,marginBottom:16}}>
              <div style={{textAlign:"center"}}><div style={{fontSize:"2.8rem",fontWeight:900,color:C.g900}}>{p.rating}</div><Stars n={p.rating}/><div style={{fontSize:"0.74rem",color:C.g400,marginTop:2}}>{p.reviews} ratings</div></div>
              <div style={{flex:1}}>{[5,4,3,2,1].map(s=><div key={s} style={{display:"flex",alignItems:"center",gap:8,marginBottom:5}}><span style={{fontSize:"0.74rem",width:8}}>{s}</span><span style={{color:"#f59e0b",fontSize:"0.7rem"}}>★</span><div style={{flex:1,height:8,background:C.g100,borderRadius:4,overflow:"hidden"}}><div style={{width:s===5?"60%":s===4?"25%":s===3?"10%":"5%",height:"100%",background:C.grn,borderRadius:4}} /></div></div>)}</div>
            </div>
            {[{n:"Anita S.",r:5,t:"Excellent! Exactly as described. Fast delivery 🙌",d:"2 days ago"},{n:"Rohit M.",r:4,t:"Good product. Happy with the purchase.",d:"1 week ago"}].map((r,i)=>(
              <div key={i} style={{borderTop:"1px solid "+C.g100,paddingTop:12,marginTop:12}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><span style={{fontWeight:700,fontSize:"0.84rem"}}>{r.n}</span><span style={{fontSize:"0.73rem",color:C.g400}}>{r.d}</span></div>
                <Stars n={r.r}/><p style={{fontSize:"0.84rem",color:C.g600,marginTop:4}}>{r.t}</p>
              </div>
            ))}
          </div>}
        </div>
      </div>
    </div>
  );
}

function Cart({cart,onBack,onQty,onRemove,onCheckout}){
  const sub=cart.reduce((s,x)=>s+(x.price*x.qty),0);
  const sav=cart.reduce((s,x)=>s+((x.original-x.price)*x.qty),0);
  if(!cart.length) return <div style={{textAlign:"center",padding:"5rem 20px"}}><div style={{fontSize:"5rem",marginBottom:14}}>🛒</div><div style={{fontWeight:800,fontSize:"1.2rem",marginBottom:8}}>Cart is empty!</div><button onClick={onBack} style={{background:C.blue,color:C.wh,border:"none",padding:"12px 28px",borderRadius:6,fontWeight:700,cursor:"pointer",fontFamily:"inherit",marginTop:8}}>Shop Now →</button></div>;
  return (
    <div style={{maxWidth:980,margin:"0 auto",padding:"20px"}}>
      <h2 style={{fontWeight:800,marginBottom:14,fontSize:"1.1rem"}}>My Cart ({cart.length} item{cart.length>1?"s":""})</h2>
      <div style={{display:"flex",gap:14,alignItems:"flex-start"}}>
        <div style={{flex:1}}>
          {cart.map(item=>(
            <div key={item.id+item.selSize} style={{background:C.wh,borderRadius:8,padding:14,marginBottom:10,display:"flex",gap:14,boxShadow:"0 1px 4px rgba(0,0,0,0.06)",border:"1px solid "+C.g100}}>
              <div style={{width:86,height:86,background:BG[item.id%BG.length],borderRadius:6,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"2.4rem",flexShrink:0}}>{item.emoji}</div>
              <div style={{flex:1}}>
                <div style={{fontWeight:700,color:C.g900,marginBottom:3,fontSize:"0.93rem"}}>{item.name}</div>
                <div style={{fontSize:"0.78rem",color:C.g400,marginBottom:7}}>Size: {item.selSize} · Seller: {item.seller}</div>
                <div style={{display:"flex",alignItems:"center",gap:7}}>
                  <span style={{fontWeight:800,fontSize:"1.02rem"}}>₹{item.price}</span>
                  <span style={{fontSize:"0.76rem",color:C.g400,textDecoration:"line-through"}}>₹{item.original}</span>
                  <span style={{fontSize:"0.72rem",color:C.grn,fontWeight:700}}>{Math.round((1-item.price/item.original)*100)}% off</span>
                </div>
              </div>
              <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:10}}>
                <div style={{display:"flex",alignItems:"center",border:"1px solid "+C.g200,borderRadius:5,overflow:"hidden"}}>
                  <button onClick={()=>item.qty>1?onQty(item.id,item.selSize,item.qty-1):onRemove(item.id,item.selSize)} style={{width:30,height:30,border:"none",background:C.g100,cursor:"pointer",fontWeight:700}}>−</button>
                  <span style={{width:34,textAlign:"center",fontWeight:700,fontSize:"0.88rem"}}>{item.qty}</span>
                  <button onClick={()=>onQty(item.id,item.selSize,item.qty+1)} style={{width:30,height:30,border:"none",background:C.g100,cursor:"pointer",fontWeight:700}}>+</button>
                </div>
                <button onClick={()=>onRemove(item.id,item.selSize)} style={{color:C.red,background:"none",border:"none",cursor:"pointer",fontSize:"0.78rem",fontFamily:"inherit"}}>Remove</button>
              </div>
            </div>
          ))}
        </div>
        <div style={{width:250,flexShrink:0,background:C.wh,borderRadius:8,boxShadow:"0 1px 4px rgba(0,0,0,0.07)",overflow:"hidden"}}>
          <div style={{background:C.g50,padding:"11px 14px",borderBottom:"1px solid "+C.g200,fontWeight:700,fontSize:"0.82rem",color:C.g600,textTransform:"uppercase",letterSpacing:0.4}}>Price Details</div>
          <div style={{padding:14}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:7,fontSize:"0.83rem",color:C.g600}}><span>Price ({cart.length} items)</span><span>₹{sub}</span></div>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:7,fontSize:"0.83rem",color:C.g600}}><span>Delivery</span><span style={{color:C.grn}}>₹40</span></div>
            <div style={{borderTop:"1px dashed "+C.g200,marginTop:9,paddingTop:9,display:"flex",justifyContent:"space-between",fontWeight:800,fontSize:"0.98rem"}}><span>Total</span><span>₹{sub+40}</span></div>
            <div style={{color:C.grn,fontSize:"0.76rem",fontWeight:600,marginTop:5}}>🎉 You save ₹{sav}!</div>
            <button onClick={onCheckout} style={{width:"100%",marginTop:14,background:C.org,color:C.wh,border:"none",padding:"12px",borderRadius:6,fontWeight:800,cursor:"pointer",fontFamily:"inherit",fontSize:"0.9rem"}}>Place Order →</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Checkout({items,onConfirmed}){
  const [step,setStep]=useState("address");
  const [addr,setAddr]=useState({name:"",phone:"",address:"",city:"",pincode:""});
  const [meth,setMeth]=useState("upi");
  const [paying,setPaying]=useState(false);
  const sub=items.reduce((s,x)=>s+(x.price*x.qty),0);

  const confirm=()=>{
    setPaying(true);
    setTimeout(()=>{ setPaying(false); onConfirmed("TFT-"+Math.random().toString(36).substr(2,8).toUpperCase()); },2000);
  };

  return (
    <div style={{maxWidth:880,margin:"0 auto",padding:"20px"}}>
      <div style={{display:"flex",alignItems:"center",marginBottom:18,background:C.wh,borderRadius:8,padding:"13px 22px",boxShadow:"0 1px 4px rgba(0,0,0,0.07)"}}>
        {[["📍","Address"],["💳","Payment"],["✅","Confirmed"]].map(([ic,l],i,arr)=>(
          <div key={l} style={{display:"flex",alignItems:"center",flex:1}}>
            <div style={{display:"flex",alignItems:"center",gap:7}}>
              <div style={{width:28,height:28,borderRadius:"50%",background:(step==="address"&&i===0)||(step==="payment"&&i<=1)||(step==="done"&&i<=2)?C.blue:C.g200,color:(step==="address"&&i===0)||(step==="payment"&&i<=1)?C.wh:C.g400,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"0.82rem",fontWeight:700}}>{i+1}</div>
              <span style={{fontSize:"0.83rem",fontWeight:((step==="address"&&i===0)||(step==="payment"&&i===1))?700:400,color:((step==="address"&&i===0)||(step==="payment"&&i===1))?C.blue:C.g400}}>{l}</span>
            </div>
            {i<arr.length-1&&<div style={{flex:1,height:2,background:C.g200,margin:"0 12px"}} />}
          </div>
        ))}
      </div>
      <div style={{display:"flex",gap:14,alignItems:"flex-start"}}>
        <div style={{flex:1}}>
          {step==="address"&&(
            <div style={{background:C.wh,borderRadius:8,boxShadow:"0 1px 4px rgba(0,0,0,0.07)",overflow:"hidden"}}>
              <div style={{background:C.blue,padding:"13px 18px",color:C.wh,fontWeight:700,fontSize:"0.93rem"}}>📍 Delivery Address</div>
              <div style={{padding:18,display:"grid",gridTemplateColumns:"1fr 1fr",gap:11}}>
                {[["Full Name","name"],["Phone","phone"],["Pincode","pincode"],["City","city"]].map(([l,k])=>(
                  <div key={k}><label style={{fontSize:"0.74rem",fontWeight:700,display:"block",marginBottom:4,color:C.g600}}>{l} *</label><input value={addr[k]} onChange={e=>setAddr(a=>({...a,[k]:e.target.value}))} style={{width:"100%",padding:"9px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.84rem",fontFamily:"inherit",outline:"none"}} /></div>
                ))}
                <div style={{gridColumn:"1/-1"}}><label style={{fontSize:"0.74rem",fontWeight:700,display:"block",marginBottom:4,color:C.g600}}>Full Address *</label><textarea value={addr.address} onChange={e=>setAddr(a=>({...a,address:e.target.value}))} rows={2} style={{width:"100%",padding:"9px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.84rem",fontFamily:"inherit",resize:"none",outline:"none"}} /></div>
              </div>
              <div style={{padding:"0 18px 18px"}}><button onClick={()=>setStep("payment")} style={{background:C.org,color:C.wh,border:"none",padding:"11px 26px",borderRadius:6,fontWeight:800,cursor:"pointer",fontFamily:"inherit",fontSize:"0.88rem"}}>Continue to Payment →</button></div>
            </div>
          )}
          {step==="payment"&&(
            <div style={{background:C.wh,borderRadius:8,boxShadow:"0 1px 4px rgba(0,0,0,0.07)",overflow:"hidden"}}>
              <div style={{background:C.blue,padding:"13px 18px",color:C.wh,fontWeight:700,fontSize:"0.93rem"}}>💳 Payment Method</div>
              {[{k:"upi",ic:"📱",l:"UPI (GPay · PhonePe · Paytm)"},{k:"card",ic:"💳",l:"Credit / Debit Card"},{k:"netbanking",ic:"🏦",l:"Net Banking"},{k:"cod",ic:"💵",l:"Cash on Delivery"}].map(m=>(
                <div key={m.k} onClick={()=>setMeth(m.k)} style={{padding:"13px 18px",borderBottom:"1px solid "+C.g100,cursor:"pointer",background:meth===m.k?C.lt:C.wh}}>
                  <div style={{display:"flex",gap:11,alignItems:"center"}}>
                    <input type="radio" checked={meth===m.k} onChange={()=>setMeth(m.k)} style={{accentColor:C.blue}} />
                    <span>{m.ic}</span>
                    <span style={{fontWeight:meth===m.k?700:500,color:meth===m.k?C.blue:C.g600,fontSize:"0.88rem"}}>{m.l}</span>
                  </div>
                  {meth===m.k&&m.k==="upi"&&<div style={{marginTop:9,marginLeft:26}}><input placeholder="Enter UPI ID (e.g. name@gpay)" style={{padding:"8px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.84rem",fontFamily:"inherit",width:270,outline:"none"}} /></div>}
                  {meth===m.k&&m.k==="card"&&<div style={{marginTop:9,marginLeft:26,display:"grid",gridTemplateColumns:"1fr 1fr",gap:9,maxWidth:360}}><div style={{gridColumn:"1/-1"}}><input placeholder="Card Number" style={{width:"100%",padding:"8px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.84rem",fontFamily:"inherit",outline:"none"}} /></div><input placeholder="MM/YY" style={{padding:"8px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.84rem",fontFamily:"inherit",outline:"none"}} /><input placeholder="CVV" style={{padding:"8px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.84rem",fontFamily:"inherit",outline:"none"}} /></div>}
                </div>
              ))}
              <div style={{margin:"14px 18px",background:"#fffbeb",border:"1px solid #fde68a",borderRadius:7,padding:"12px 14px"}}>
                <div style={{fontWeight:700,color:"#92400e",marginBottom:3,fontSize:"0.86rem"}}>🔒 Order Confirmation Fee</div>
                <div style={{fontSize:"0.8rem",color:"#78350f",lineHeight:1.6}}>A one-time <strong>₹12 fee</strong> via Razorpay confirms your order and prevents fake bookings.</div>
              </div>
              <div style={{padding:"0 18px 18px",display:"flex",gap:9}}>
                <button onClick={()=>setStep("address")} style={{background:C.wh,color:C.g600,border:"1px solid "+C.g200,padding:"11px 18px",borderRadius:6,fontWeight:600,cursor:"pointer",fontFamily:"inherit",fontSize:"0.86rem"}}>← Back</button>
                <button onClick={confirm} disabled={paying} style={{background:paying?C.g400:C.org,color:C.wh,border:"none",padding:"11px 28px",borderRadius:6,fontWeight:800,cursor:paying?"not-allowed":"pointer",fontFamily:"inherit",fontSize:"0.9rem"}}>
                  {paying?"Processing ₹12 fee...":"Pay ₹12 & Confirm Order 🔒"}
                </button>
              </div>
            </div>
          )}
        </div>
        <div style={{width:248,flexShrink:0,background:C.wh,borderRadius:8,boxShadow:"0 1px 4px rgba(0,0,0,0.07)",overflow:"hidden"}}>
          <div style={{background:C.g50,padding:"11px 14px",borderBottom:"1px solid "+C.g200,fontWeight:700,fontSize:"0.8rem",color:C.g600,textTransform:"uppercase"}}>Order Summary</div>
          <div style={{padding:14}}>
            {items.map(item=>(
              <div key={item.id} style={{display:"flex",gap:8,marginBottom:9,paddingBottom:9,borderBottom:"1px solid "+C.g100}}>
                <span style={{fontSize:"1.4rem"}}>{item.emoji}</span>
                <div style={{flex:1}}><div style={{fontSize:"0.79rem",fontWeight:600,lineHeight:1.3}}>{item.name}</div><div style={{fontSize:"0.72rem",color:C.g400}}>Size: {item.selSize} ×{item.qty}</div></div>
                <div style={{fontWeight:700,fontSize:"0.88rem"}}>₹{item.price*item.qty}</div>
              </div>
            ))}
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:5,fontSize:"0.82rem",color:C.g600}}><span>Subtotal</span><span>₹{sub}</span></div>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:5,fontSize:"0.82rem",color:C.g600}}><span>Delivery</span><span>₹40</span></div>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:5,fontSize:"0.82rem",color:C.blue,fontWeight:600}}><span>Confirmation Fee</span><span>₹12</span></div>
            <div style={{borderTop:"1px dashed "+C.g200,marginTop:7,paddingTop:7,display:"flex",justifyContent:"space-between",fontWeight:800,fontSize:"0.97rem"}}><span>Total</span><span>₹{sub+52}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Confirmed({orderId,onHome}){
  const del=new Date(); del.setDate(del.getDate()+5);
  return (
    <div style={{maxWidth:600,margin:"40px auto",padding:"20px",textAlign:"center"}}>
      <div style={{background:C.wh,borderRadius:12,boxShadow:"0 8px 32px rgba(0,0,0,0.09)",padding:"40px 30px"}}>
        <div style={{fontSize:"4rem",marginBottom:14}}>✅</div>
        <h1 style={{fontSize:"1.55rem",fontWeight:900,color:C.grn,marginBottom:7}}>Order Confirmed!</h1>
        <p style={{color:C.g400,marginBottom:4,fontSize:"0.88rem"}}>Order ID: <strong style={{color:C.g900,fontFamily:"monospace"}}>#{orderId}</strong></p>
        <p style={{color:C.g400,fontSize:"0.83rem",marginBottom:22}}>Confirmation sent to your mobile</p>
        <div style={{background:"#f0fdf4",border:"1px solid #bbf7d0",borderRadius:8,padding:14,marginBottom:18}}>
          <div style={{fontWeight:700,color:"#15803d",marginBottom:3}}>🚚 Expected Delivery</div>
          <div style={{fontSize:"1.05rem",fontWeight:800,color:C.g900}}>{del.toLocaleDateString("en-IN",{weekday:"long",day:"numeric",month:"long"})}</div>
          <div style={{fontSize:"0.74rem",color:C.g400,marginTop:3}}>via Shiprocket</div>
        </div>
        <div style={{background:C.lt,borderRadius:8,padding:14,marginBottom:22}}>
          <div style={{fontWeight:700,color:C.blue,marginBottom:10,fontSize:"0.86rem"}}>📦 Order Tracking</div>
          <div style={{display:"flex",justifyContent:"space-between",position:"relative"}}>
            <div style={{position:"absolute",top:13,left:"10%",right:"10%",height:2,background:C.bd}} />
            {["✅ Confirmed","📦 Packed","🚚 Shipped","🏠 Delivered"].map((s,i)=>(
              <div key={s} style={{textAlign:"center",position:"relative",zIndex:1}}>
                <div style={{width:26,height:26,borderRadius:"50%",background:i===0?C.blue:C.g200,color:i===0?C.wh:C.g400,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"0.7rem",margin:"0 auto 4px",fontWeight:700}}>{i+1}</div>
                <div style={{fontSize:"0.62rem",color:i===0?C.blue:C.g400,fontWeight:i===0?700:400}}>{s.split(" ").slice(1).join(" ")}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={{display:"flex",gap:10,justifyContent:"center"}}>
          <button onClick={onHome} style={{background:C.blue,color:C.wh,border:"none",padding:"11px 26px",borderRadius:6,fontWeight:700,cursor:"pointer",fontFamily:"inherit",fontSize:"0.88rem"}}>Continue Shopping</button>
          <button style={{background:C.wh,color:C.blue,border:"1.5px solid "+C.blue,padding:"11px 26px",borderRadius:6,fontWeight:700,cursor:"pointer",fontFamily:"inherit",fontSize:"0.88rem"}}>My Orders</button>
        </div>
      </div>
    </div>
  );
}

function LoginModal({onClose,onLogin}){
  const [mode,setMode]=useState("login"); const [type,setType]=useState("buyer");
  const [form,setForm]=useState({name:"",mobile:"",password:"",shopName:"",upiId:""});
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.55)",zIndex:500,display:"flex",alignItems:"center",justifyContent:"center"}} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{background:C.wh,borderRadius:10,width:410,boxShadow:"0 24px 64px rgba(0,0,0,0.2)",overflow:"hidden"}}>
        <div style={{background:C.blue,padding:"18px 22px",color:C.wh,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <span style={{fontSize:"1.05rem",fontWeight:800}}>{mode==="login"?"Welcome Back 👋":"Join TFT Store"}</span>
          <button onClick={onClose} style={{background:"none",border:"none",color:C.wh,fontSize:"1.3rem",cursor:"pointer",lineHeight:1}}>✕</button>
        </div>
        <div style={{padding:22}}>
          <div style={{display:"flex",marginBottom:18,border:"1px solid "+C.g200,borderRadius:6,overflow:"hidden"}}>
            {["buyer","seller"].map(t=><button key={t} onClick={()=>setType(t)} style={{flex:1,padding:"10px",border:"none",background:type===t?C.blue:C.wh,color:type===t?C.wh:C.g600,fontWeight:700,cursor:"pointer",fontFamily:"inherit",fontSize:"0.86rem",transition:"all 0.15s"}}>{t==="buyer"?"🛍️ Buyer":"🏪 Seller"}</button>)}
          </div>
          {mode==="register"&&<div style={{marginBottom:12}}><label style={{fontSize:"0.74rem",fontWeight:700,display:"block",marginBottom:4,color:C.g600}}>Full Name</label><input value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} style={{width:"100%",padding:"10px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.86rem",fontFamily:"inherit",outline:"none"}} /></div>}
          <div style={{marginBottom:12}}><label style={{fontSize:"0.74rem",fontWeight:700,display:"block",marginBottom:4,color:C.g600}}>Mobile Number</label><input value={form.mobile} onChange={e=>setForm(f=>({...f,mobile:e.target.value}))} placeholder="+91 98765 43210" style={{width:"100%",padding:"10px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.86rem",fontFamily:"inherit",outline:"none"}} /></div>
          <div style={{marginBottom:12}}><label style={{fontSize:"0.74rem",fontWeight:700,display:"block",marginBottom:4,color:C.g600}}>Password</label><input type="password" value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))} style={{width:"100%",padding:"10px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.86rem",fontFamily:"inherit",outline:"none"}} /></div>
          {mode==="register"&&type==="seller"&&<>
            <div style={{marginBottom:12}}><label style={{fontSize:"0.74rem",fontWeight:700,display:"block",marginBottom:4,color:C.g600}}>Shop Name</label><input value={form.shopName} onChange={e=>setForm(f=>({...f,shopName:e.target.value}))} style={{width:"100%",padding:"10px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.86rem",fontFamily:"inherit",outline:"none"}} /></div>
            <div style={{marginBottom:12}}><label style={{fontSize:"0.74rem",fontWeight:700,display:"block",marginBottom:4,color:C.g600}}>UPI ID (for payments)</label><input value={form.upiId} onChange={e=>setForm(f=>({...f,upiId:e.target.value}))} placeholder="name@upi" style={{width:"100%",padding:"10px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.86rem",fontFamily:"inherit",outline:"none"}} /></div>
          </>}
          <button onClick={()=>{onLogin(form.name||"User",type);onClose();}} style={{width:"100%",background:C.blue,color:C.wh,border:"none",padding:"12px",borderRadius:6,fontWeight:800,cursor:"pointer",fontFamily:"inherit",fontSize:"0.93rem",marginBottom:13}}>
            {mode==="login"?"Login →":"Create Account →"}
          </button>
          <div style={{textAlign:"center",fontSize:"0.82rem",color:C.g400}}>
            {mode==="login"?<span>New here? <span onClick={()=>setMode("register")} style={{color:C.blue,cursor:"pointer",fontWeight:700}}>Create account</span></span>:<span>Have account? <span onClick={()=>setMode("login")} style={{color:C.blue,cursor:"pointer",fontWeight:700}}>Login</span></span>}
          </div>
        </div>
      </div>
    </div>
  );
}

function SellerDash({user}){
  const [tab,setTab]=useState("overview");
  const [showAdd,setShowAdd]=useState(false);
  const [np,setNp]=useState({name:"",brand:"",category:"Women",condition:"Good",price:"",original:"",desc:""});
  const myProds=PRODUCTS.filter(p=>p.seller==="Priya NGO");
  const stats=[{l:"Products",v:myProds.length,ic:"📦",col:C.blue},{l:"Total Orders",v:47,ic:"🛒",col:C.org},{l:"Delivered",v:38,ic:"✅",col:C.grn},{l:"Earnings",v:"₹18,420",ic:"💰",col:"#7c3aed"}];
  return (
    <div style={{maxWidth:1200,margin:"0 auto",padding:"20px"}}>
      <div style={{background:"linear-gradient(135deg,"+C.dk+","+C.blue+")",borderRadius:10,padding:"20px 24px",marginBottom:18,color:C.wh,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontSize:"0.73rem",opacity:0.8,marginBottom:4}}>Seller Dashboard</div>
          <div style={{fontSize:"1.35rem",fontWeight:800}}>Welcome, {user||"Priya NGO"} 👋</div>
          <div style={{fontSize:"0.82rem",opacity:0.8,marginTop:3}}>Manage your listings, orders and earnings</div>
        </div>
        <button onClick={()=>setShowAdd(true)} style={{background:C.wh,color:C.blue,border:"none",padding:"11px 22px",borderRadius:8,fontWeight:800,cursor:"pointer",fontFamily:"inherit",fontSize:"0.88rem"}}>+ Add Product</button>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:13,marginBottom:18}}>
        {stats.map((s,i)=>(
          <div key={i} style={{background:C.wh,borderRadius:8,padding:"15px 18px",boxShadow:"0 1px 4px rgba(0,0,0,0.07)",border:"1px solid "+C.g100,display:"flex",alignItems:"center",gap:13}}>
            <div style={{width:44,height:44,borderRadius:10,background:s.col+"18",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.3rem"}}>{s.ic}</div>
            <div><div style={{fontSize:"1.4rem",fontWeight:900,color:s.col}}>{s.v}</div><div style={{fontSize:"0.73rem",color:C.g400,fontWeight:500}}>{s.l}</div></div>
          </div>
        ))}
      </div>
      <div style={{background:C.wh,borderRadius:8,boxShadow:"0 1px 4px rgba(0,0,0,0.07)",overflow:"hidden"}}>
        <div style={{display:"flex",borderBottom:"1px solid "+C.g200}}>
          {[["overview","📊 Overview"],["orders","🛒 Orders"],["products","📦 Products"],["earnings","💰 Earnings"]].map(([k,l])=>(
            <button key={k} onClick={()=>setTab(k)} style={{padding:"12px 20px",border:"none",background:"none",cursor:"pointer",fontFamily:"inherit",fontSize:"0.84rem",fontWeight:tab===k?700:500,color:tab===k?C.blue:C.g400,borderBottom:tab===k?"2px solid "+C.blue:"2px solid transparent"}}>{l}</button>
          ))}
        </div>
        <div style={{padding:18}}>
          {(tab==="overview"||tab==="orders")&&(
            <div>
              <div style={{fontWeight:700,marginBottom:13,color:C.g900,fontSize:"0.93rem"}}>{tab==="overview"?"Recent Orders":"All Orders"} ({SELLER_ORDERS.length})</div>
              {tab==="orders"
                ? SELLER_ORDERS.map(o=>(
                    <div key={o.id} style={{border:"1px solid "+C.g200,borderRadius:8,padding:14,marginBottom:9,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div style={{display:"flex",gap:12,alignItems:"center"}}>
                        <div style={{width:46,height:46,background:C.lt,borderRadius:7,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.4rem"}}>👗</div>
                        <div>
                          <div style={{fontWeight:700,color:C.g900,fontSize:"0.88rem"}}>{o.product}</div>
                          <div style={{fontSize:"0.76rem",color:C.g400}}>Order: <span style={{fontFamily:"monospace",color:C.blue}}>{o.id}</span></div>
                          <div style={{fontSize:"0.76rem",color:C.g400}}>Buyer: {o.buyer} · {o.city}</div>
                        </div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontWeight:800,fontSize:"0.98rem",marginBottom:4}}>₹{o.price}</div>
                        <span style={{fontSize:"0.7rem",padding:"3px 10px",borderRadius:20,background:statusStyle[o.status][0],color:statusStyle[o.status][1],fontWeight:700,textTransform:"capitalize"}}>{o.status}</span>
                        <div style={{fontSize:"0.72rem",color:C.g400,marginTop:3}}>{o.date}</div>
                      </div>
                    </div>
                  ))
                : <table style={{width:"100%",borderCollapse:"collapse"}}>
                    <thead><tr style={{background:C.g50}}>{["Order ID","Product","Buyer","Amount","Status","Date"].map(h=><th key={h} style={{padding:"9px 11px",textAlign:"left",fontSize:"0.73rem",fontWeight:700,color:C.g600,textTransform:"uppercase",letterSpacing:0.4}}>{h}</th>)}</tr></thead>
                    <tbody>{SELLER_ORDERS.map((o,i)=>(
                      <tr key={o.id} style={{borderBottom:"1px solid "+C.g100,background:i%2===0?C.wh:C.g50}}>
                        <td style={{padding:"9px 11px",fontSize:"0.79rem",fontFamily:"monospace",color:C.blue,fontWeight:600}}>{o.id}</td>
                        <td style={{padding:"9px 11px",fontSize:"0.82rem",fontWeight:500}}>{o.product}</td>
                        <td style={{padding:"9px 11px",fontSize:"0.82rem",color:C.g600}}>{o.buyer} · {o.city}</td>
                        <td style={{padding:"9px 11px",fontSize:"0.82rem",fontWeight:700}}>₹{o.price}</td>
                        <td style={{padding:"9px 11px"}}><span style={{fontSize:"0.7rem",padding:"3px 9px",borderRadius:20,background:statusStyle[o.status][0],color:statusStyle[o.status][1],fontWeight:700,textTransform:"capitalize"}}>{o.status}</span></td>
                        <td style={{padding:"9px 11px",fontSize:"0.76rem",color:C.g400}}>{o.date}</td>
                      </tr>
                    ))}</tbody>
                  </table>
              }
            </div>
          )}
          {tab==="products"&&(
            <div>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:13}}>
                <div style={{fontWeight:700,color:C.g900}}>My Products ({myProds.length})</div>
                <button onClick={()=>setShowAdd(true)} style={{background:C.blue,color:C.wh,border:"none",padding:"7px 16px",borderRadius:6,fontWeight:700,cursor:"pointer",fontFamily:"inherit",fontSize:"0.82rem"}}>+ Add Product</button>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(190px,1fr))",gap:11}}>
                {myProds.map((p,i)=>(
                  <div key={p.id} style={{border:"1px solid "+C.g200,borderRadius:8,overflow:"hidden"}}>
                    <div style={{height:130,background:BG[i%BG.length],display:"flex",alignItems:"center",justifyContent:"center",fontSize:"2.8rem"}}>{p.emoji}</div>
                    <div style={{padding:"9px 11px"}}>
                      <div style={{fontWeight:600,fontSize:"0.83rem",color:C.g900,marginBottom:3}}>{p.name}</div>
                      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:7}}><span style={{fontWeight:800,color:C.grn,fontSize:"0.95rem"}}>₹{p.price}</span><span style={{fontSize:"0.65rem",padding:"2px 7px",borderRadius:3,background:condStyle[p.condition][0],color:condStyle[p.condition][1],fontWeight:700}}>{p.condition}</span></div>
                      <div style={{display:"flex",gap:5}}>
                        <button style={{flex:1,background:C.lt,color:C.blue,border:"1px solid "+C.bd,borderRadius:4,padding:"5px",fontSize:"0.73rem",fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>Edit</button>
                        <button style={{flex:1,background:"#fef2f2",color:C.red,border:"1px solid #fecaca",borderRadius:4,padding:"5px",fontSize:"0.73rem",fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>Remove</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {tab==="earnings"&&(
            <div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:13,marginBottom:18}}>
                {[["Total Earned","₹18,420",C.grn],["Pending Payout","₹3,240",C.org],["TFT Commission (4%)","₹768",C.blue]].map(([l,v,col])=>(
                  <div key={l} style={{background:C.wh,border:"1px solid "+C.g200,borderRadius:8,padding:14,textAlign:"center"}}>
                    <div style={{fontSize:"1.7rem",fontWeight:900,color:col,marginBottom:3}}>{v}</div>
                    <div style={{fontSize:"0.75rem",color:C.g400,fontWeight:500}}>{l}</div>
                  </div>
                ))}
              </div>
              <div style={{fontWeight:700,marginBottom:11,color:C.g900}}>Earnings Breakdown</div>
              <table style={{width:"100%",borderCollapse:"collapse"}}>
                <thead><tr style={{background:C.g50}}>{["Order ID","Product","Sale Price","TFT 4%","Your Earning","Date"].map(h=><th key={h} style={{padding:"9px 11px",textAlign:"left",fontSize:"0.72rem",fontWeight:700,color:C.g600,textTransform:"uppercase",letterSpacing:0.4}}>{h}</th>)}</tr></thead>
                <tbody>{SELLER_ORDERS.filter(o=>o.status==="delivered").map((o,i)=>(
                  <tr key={o.id} style={{borderBottom:"1px solid "+C.g100,background:i%2===0?C.wh:C.g50}}>
                    <td style={{padding:"9px 11px",fontSize:"0.78rem",fontFamily:"monospace",color:C.blue}}>{o.id}</td>
                    <td style={{padding:"9px 11px",fontSize:"0.8rem"}}>{o.product}</td>
                    <td style={{padding:"9px 11px",fontSize:"0.8rem",fontWeight:700}}>₹{o.price}</td>
                    <td style={{padding:"9px 11px",fontSize:"0.8rem",color:C.red}}>-₹{Math.round(o.price*0.04)}</td>
                    <td style={{padding:"9px 11px",fontSize:"0.8rem",fontWeight:700,color:C.grn}}>₹{Math.round(o.price*0.96)}</td>
                    <td style={{padding:"9px 11px",fontSize:"0.76rem",color:C.g400}}>{o.date}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          )}
        </div>
      </div>
      {showAdd&&(
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:500,display:"flex",alignItems:"center",justifyContent:"center"}} onClick={()=>setShowAdd(false)}>
          <div onClick={e=>e.stopPropagation()} style={{background:C.wh,borderRadius:10,width:490,maxHeight:"85vh",overflow:"auto",boxShadow:"0 24px 64px rgba(0,0,0,0.2)"}}>
            <div style={{background:C.blue,padding:"15px 18px",color:C.wh,display:"flex",justifyContent:"space-between",alignItems:"center",position:"sticky",top:0}}>
              <span style={{fontWeight:800,fontSize:"0.98rem"}}>📦 Add New Product</span>
              <button onClick={()=>setShowAdd(false)} style={{background:"none",border:"none",color:C.wh,fontSize:"1.3rem",cursor:"pointer"}}>✕</button>
            </div>
            <div style={{padding:18,display:"grid",gridTemplateColumns:"1fr 1fr",gap:11}}>
              {[["Product Name","name"],["Brand","brand"],["Price (₹)","price"],["Original Price (₹)","original"]].map(([l,k])=>(
                <div key={k}><label style={{fontSize:"0.73rem",fontWeight:700,display:"block",marginBottom:4,color:C.g600}}>{l}</label><input value={np[k]} onChange={e=>setNp(p=>({...p,[k]:e.target.value}))} style={{width:"100%",padding:"8px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.84rem",fontFamily:"inherit",outline:"none"}} /></div>
              ))}
              <div><label style={{fontSize:"0.73rem",fontWeight:700,display:"block",marginBottom:4,color:C.g600}}>Category</label><select value={np.category} onChange={e=>setNp(p=>({...p,category:e.target.value}))} style={{width:"100%",padding:"8px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.84rem",fontFamily:"inherit",outline:"none"}}>{["Women","Men","Kids","Footwear","Accessories"].map(c=><option key={c}>{c}</option>)}</select></div>
              <div><label style={{fontSize:"0.73rem",fontWeight:700,display:"block",marginBottom:4,color:C.g600}}>Condition</label><select value={np.condition} onChange={e=>setNp(p=>({...p,condition:e.target.value}))} style={{width:"100%",padding:"8px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.84rem",fontFamily:"inherit",outline:"none"}}>{["Like New","Good","Fair"].map(c=><option key={c}>{c}</option>)}</select></div>
              <div style={{gridColumn:"1/-1"}}><label style={{fontSize:"0.73rem",fontWeight:700,display:"block",marginBottom:4,color:C.g600}}>Description</label><textarea value={np.desc} onChange={e=>setNp(p=>({...p,desc:e.target.value}))} rows={3} style={{width:"100%",padding:"8px 11px",border:"1px solid "+C.g200,borderRadius:5,fontSize:"0.84rem",fontFamily:"inherit",resize:"none",outline:"none"}} /></div>
              <div style={{gridColumn:"1/-1",background:C.g50,borderRadius:6,padding:11,border:"1px dashed "+C.g200,textAlign:"center",cursor:"pointer"}}>
                <div style={{fontSize:"1.4rem",marginBottom:3}}>📸</div>
                <div style={{fontSize:"0.79rem",color:C.g400}}>Click to upload photos (min 1, max 5)</div>
              </div>
            </div>
            <div style={{padding:"0 18px 18px",display:"flex",gap:9}}>
              <button onClick={()=>setShowAdd(false)} style={{background:C.wh,color:C.g600,border:"1px solid "+C.g200,padding:"10px 18px",borderRadius:6,fontWeight:600,cursor:"pointer",fontFamily:"inherit",fontSize:"0.86rem"}}>Cancel</button>
              <button onClick={()=>setShowAdd(false)} style={{background:C.blue,color:C.wh,border:"none",padding:"10px 26px",borderRadius:6,fontWeight:800,cursor:"pointer",fontFamily:"inherit",fontSize:"0.88rem",flex:1}}>✅ List Product</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App(){
  const [mode,setMode]=useState("customer");
  const [page,setPage]=useState("home");
  const [sel,setSel]=useState(null);
  const [cart,setCart]=useState([]);
  const [wish,setWish]=useState([]);
  const [buy,setBuy]=useState([]);
  const [oid,setOid]=useState("");
  const [user,setUser]=useState(null);
  const [search,setSearch]=useState("");
  const [showLogin,setShowLogin]=useState(false);
  const [toast,setToast]=useState("");

  const showT=msg=>{setToast(msg);setTimeout(()=>setToast(""),2500);};

  const addCart=p=>{
    if(!user){setShowLogin(true);return;}
    setCart(c=>{const e=c.find(x=>x.id===p.id&&x.selSize===p.selSize);if(e)return c.map(x=>x.id===p.id&&x.selSize===p.selSize?{...x,qty:x.qty+p.qty}:x);return[...c,p];});
    showT("🛒 Added to cart!");
  };
  const buyNow=p=>{if(!user){setShowLogin(true);return;}setBuy([p]);setPage("checkout");};
  const toggleWish=id=>{if(!user){setShowLogin(true);return;}setWish(w=>w.includes(id)?w.filter(x=>x!==id):[...w,id]);showT(wish.includes(id)?"Removed from wishlist":"❤️ Saved!");};
  const cartCount=cart.reduce((s,x)=>s+x.qty,0);

  useEffect(()=>{setPage(mode==="seller"?"seller":"home");},[mode]);

  return (
    <div style={{minHeight:"100vh",background:"#f8fafc",fontFamily:"'Segoe UI',system-ui,sans-serif"}}>
      <style>{"*{box-sizing:border-box;margin:0;padding:0;}input,select,textarea,button{font-family:inherit;}@keyframes toastIn{from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);}}"}</style>
      <Header mode={mode} setMode={setMode} cartCount={cartCount} wishCount={wish.length} search={search} setSearch={setSearch} onCart={()=>setPage("cart")} onLogo={()=>{setPage(mode==="seller"?"seller":"home");setSearch("");}} onLogin={()=>setShowLogin(true)} user={user} onLogout={()=>{setUser(null);showT("Logged out!");}} />
      <main>
        {page==="home"     &&<Home search={search} onView={p=>{setSel(p);setPage("product");}} wish={wish} onWish={toggleWish} onCart={addCart} />}
        {page==="product"  &&sel&&<Detail p={sel} onBack={()=>setPage("home")} onCart={addCart} onBuy={buyNow} onWish={toggleWish} wished={wish.includes(sel.id)} />}
        {page==="cart"     &&<Cart cart={cart} onBack={()=>setPage("home")} onQty={(id,s,q)=>setCart(c=>c.map(x=>x.id===id&&x.selSize===s?{...x,qty:q}:x))} onRemove={(id,s)=>setCart(c=>c.filter(x=>!(x.id===id&&x.selSize===s)))} onCheckout={()=>{setBuy(cart);setPage("checkout");}} />}
        {page==="checkout" &&<Checkout items={buy} onConfirmed={id=>{setOid(id);setCart([]);setPage("confirmed");}} />}
        {page==="confirmed"&&<Confirmed orderId={oid} onHome={()=>setPage("home")} />}
        {page==="seller"   &&<SellerDash user={user} />}
      </main>
      {showLogin&&<LoginModal onClose={()=>setShowLogin(false)} onLogin={(name,type)=>{setUser(name);showT("✅ Welcome, "+name+"!");if(type==="seller")setMode("seller");}} />}
      {toast&&<div style={{position:"fixed",bottom:24,left:"50%",transform:"translateX(-50%)",background:"#0f172a",color:"#fff",padding:"11px 22px",borderRadius:8,fontWeight:600,fontSize:"0.86rem",zIndex:999,animation:"toastIn 0.3s ease",boxShadow:"0 8px 24px rgba(0,0,0,0.2)",whiteSpace:"nowrap"}}>{toast}</div>}
    </div>
  );
}
