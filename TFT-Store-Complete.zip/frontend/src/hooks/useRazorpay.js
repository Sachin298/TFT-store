// src/hooks/useRazorpay.js
import { paymentAPI } from '../api/api';

// Load Razorpay script dynamically
const loadRazorpayScript = () =>
  new Promise((resolve) => {
    if (document.getElementById('razorpay-script')) return resolve(true);
    const script = document.createElement('script');
    script.id  = 'razorpay-script';
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload  = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });

export function useRazorpay() {

  // ── Step 1: Pay ₹12 confirmation fee ─────────────────────
  const payConfirmationFee = (orderId, { onSuccess, onError, buyerName, buyerMobile }) =>
    new Promise(async (resolve, reject) => {
      try {
        await loadRazorpayScript();

        const { razorpayOrderId, amount, currency, key } =
          await paymentAPI.createConfirmFee(orderId);

        const options = {
          key,
          amount,
          currency,
          name:        'TFT Store',
          description: 'Order Confirmation Fee',
          order_id:    razorpayOrderId,
          prefill:     { name: buyerName, contact: buyerMobile },
          theme:       { color: '#2563eb' },

          handler: async (response) => {
            try {
              const result = await paymentAPI.verifyConfirmFee({
                razorpay_order_id:   response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature:  response.razorpay_signature,
                orderId,
              });
              onSuccess?.(result);
              resolve(result);
            } catch (err) {
              onError?.(err);
              reject(err);
            }
          },

          modal: { ondismiss: () => reject(new Error('Payment cancelled')) },
        };

        new window.Razorpay(options).open();
      } catch (err) {
        onError?.(err);
        reject(err);
      }
    });

  // ── Step 2: Pay product price ─────────────────────────────
  const payProductAmount = (orderId, { onSuccess, onError, buyerName, buyerMobile }) =>
    new Promise(async (resolve, reject) => {
      try {
        await loadRazorpayScript();

        const { razorpayOrderId, amount, currency, key } =
          await paymentAPI.createProductPay(orderId);

        const options = {
          key,
          amount,
          currency,
          name:        'TFT Store',
          description: 'Product Payment',
          order_id:    razorpayOrderId,
          prefill:     { name: buyerName, contact: buyerMobile },
          theme:       { color: '#2563eb' },

          handler: async (response) => {
            try {
              const result = await paymentAPI.verifyProductPay({
                razorpay_order_id:   response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature:  response.razorpay_signature,
                orderId,
              });
              onSuccess?.(result);
              resolve(result);
            } catch (err) {
              onError?.(err);
              reject(err);
            }
          },

          modal: { ondismiss: () => reject(new Error('Payment cancelled')) },
        };

        new window.Razorpay(options).open();
      } catch (err) {
        onError?.(err);
        reject(err);
      }
    });

  return { payConfirmationFee, payProductAmount };
}
