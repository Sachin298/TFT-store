// src/App.js
import { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { productAPI, orderAPI } from './api/api';
import { useRazorpay } from './hooks/useRazorpay';

// ── Colours ──────────────────────────────────────────────
const C = {
  blue:    '#2563eb', blueDark:'#1d4ed8', bluePale:'#eff6ff',
  blueBdr: '#bfdbfe', white:   '#ffffff', gray50:  '#f8fafc',
  gray100: '#f1f5f9', gray200: '#e2e8f0', gray400: '#94a3b8',
  gray600: '#475569', gray900: '#0f172a', green:   '#16a34a',
  orange:  '#f97316', red:     '#ef4444',
};
const cardBg = ['#EFF6FF','#F0FDF4','#FFF7ED','#FAF5FF','#F0F9FF','#FDF4FF'];
const condBadge = { 'Like New':['#dbeafe','#1d4ed8'],'Good':['#dcfce7','#15803d'],'Fair':['#fef9c3','#a16207'] };
const CATEGORIES = ['All','Women','Men','Kids','Footwear'];

// ── Helpers ───────────────────────────────────────────────
function Stars({ n }) {
  return <span style={{ color:'#f59e0b', fontSize:'0.8rem' }}>{'★'.repeat(Math.floor(n))}{'☆'.repeat(5-Math.floor(n))}</span>;
}
function Toast({ msg }) {
  return msg ? (
    <div style={{ position:'fixed', bottom:24, left:'50%', transform:'translateX(-50%)', background:C.gray900, color:'#fff', padding:'12px 24px', borderRadius:8, fontWeight:600, fontSize:'0.88rem', zIndex:999, boxShadow:'0 8px 24px rgba(0,0,0,0.2)', whiteSpace:'nowrap' }}>
      {msg}
    </div>
  ) : null;
}
function Spinner() {
  return <div style={{ textAlign:'center', padding:'4rem', color:C.gray400, fontSize:'1rem' }}>Loading...</div>;
}

// ── Header ────────────────────────────────────────────────
function Header({ cartCount, wishCount, onSearch, search, onCart, onLogo, onLogin, user, onLogout }) {
  return (
    <header style={{ background:C.blue, position:'sticky', top:0, zIndex:200, boxShadow:'0 2px 8px rgba(0,0,0,0.15)' }}>
      <div style={{ maxWidth:1280, margin:'0 auto', padding:'0 20px', display:'flex', alignItems:'center', gap:16, height:56 }}>
        <div onClick={onLogo} style={{ cursor:'pointer', flexShrink:0 }}>
          <span style={{ fontFamily:'Georgia,serif', fontSize:'1.4rem', fontWeight:900, color:'#fff' }}>TFT</span>
          <span style={{ fontFamily:'Georgia,serif', fontSize:'1.4rem', color:'#bfdbfe' }}> Store</span>
        </div>
        <div style={{ flex:1, display:'flex', maxWidth:600 }}>
          <input value={search} onChange={e=>onSearch(e.target.value)} placeholder="Search clothes, brands..." style={{ flex:1, height:36, padding:'0 14px', border:'none', borderRadius:'4px 0 0 4px', fontSize:'0.88rem', fontFamily:'inherit', outline:'none' }} />
          <button style={{ width:44, height:36, background:C.orange, border:'none', borderRadius:'0 4px 4px 0', cursor:'pointer', fontSize:'1.1rem' }}>🔍</button>
        </div>
        <div style={{ display:'flex', gap:16, alignItems:'center', flexShrink:0 }}>
          {user ? (
            <>
              <span style={{ color:'#fff', fontSize:'0.85rem', fontWeight:600 }}>Hi, {user.name.split(' ')[0]}!</span>
              <span onClick={onLogout} style={{ color:'#bfdbfe', fontSize:'0.82rem', cursor:'pointer' }}>Logout</span>
            </>
          ) : (
            <span onClick={onLogin} style={{ color:'#fff', fontSize:'0.85rem', cursor:'pointer', fontWeight:600 }}>Login</span>
          )}
          <div onClick={onCart} style={{ display:'flex', alignItems:'center', gap:6, cursor:'pointer', color:'#fff', position:'relative' }}>
            <span style={{ fontSize:'1.3rem' }}>🛒</span>
            <span style={{ fontSize:'0.85rem', fontWeight:700 }}>Cart</span>
            {cartCount > 0 && <span style={{ position:'absolute', top:-8, right:-8, background:C.orange, borderRadius:'50%', width:18, height:18, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'0.65rem', fontWeight:700 }}>{cartCount}</span>}
          </div>
          <div style={{ color:'#fff', cursor:'pointer' }}>❤️ {wishCount}</div>
        </div>
      </div>
      <div style={{ background:C.blueDark }}>
        <div style={{ maxWidth:1280, margin:'0 auto', padding:'0 20px', display:'flex', gap:4 }}>
          {CATEGORIES.map(c => <span key={c} style={{ color:'#e0f2fe', fontSize:'0.8rem', padding:'6px 14px', cursor:'pointer', whiteSpace:'nowrap' }}>{c}</span>)}
          <span style={{ color:'#fbbf24', fontSize:'0.8rem', padding:'6px 14px', cursor:'pointer', fontWeight:700 }}>🔥 Best Deals</span>
        </div>
      </div>
    </header>
  );
}

// ── Product Card ──────────────────────────────────────────
function ProductCard({ product, index, onView, onWishlist, wishlisted }) {
  const discount = Math.round((1 - product.price / product.original) * 100);
  return (
    <div onClick={() => onView(product)} style={{ background:C.white, cursor:'pointer', border:'1px solid '+C.gray200, transition:'box-shadow 0.15s', position:'relative' }}
      onMouseEnter={e => e.currentTarget.style.boxShadow='0 4px 20px rgba(0,0,0,0.1)'}
      onMouseLeave={e => e.currentTarget.style.boxShadow='none'}
    >
      <button onClick={e => { e.stopPropagation(); onWishlist(product._id); }} style={{ position:'absolute', top:8, right:8, background:'rgba(255,255,255,0.9)', border:'none', borderRadius:'50%', width:30, height:30, cursor:'pointer', fontSize:'0.95rem', zIndex:1 }}>
        {wishlisted ? '❤️' : '🤍'}
      </button>
      <div style={{ height:200, background:cardBg[index % cardBg.length], display:'flex', alignItems:'center', justifyContent:'center', fontSize:'3.5rem' }}>
        {product.images?.[0] ? <img src={product.images[0]} alt={product.name} style={{ width:'100%', height:'100%', objectFit:'cover' }} /> : '👗'}
      </div>
      <div style={{ padding:'10px 12px 14px' }}>
        <div style={{ fontSize:'0.75rem', color:C.gray400, marginBottom:2 }}>{product.brand}</div>
        <div style={{ fontSize:'0.88rem', fontWeight:600, color:'#111', marginBottom:4, overflow:'hidden', display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical' }}>{product.name}</div>
        <div style={{ display:'flex', alignItems:'center', gap:4, marginBottom:6 }}>
          <span style={{ background:C.green, color:'#fff', fontSize:'0.7rem', padding:'2px 6px', borderRadius:2, fontWeight:700 }}>{product.rating || 4.5} ★</span>
          <span style={{ color:C.gray400, fontSize:'0.72rem' }}>({product.numReviews || 0})</span>
        </div>
        <div style={{ display:'flex', alignItems:'baseline', gap:6 }}>
          <span style={{ fontSize:'1.05rem', fontWeight:800 }}>₹{product.price}</span>
          <span style={{ fontSize:'0.78rem', color:C.gray400, textDecoration:'line-through' }}>₹{product.original}</span>
          <span style={{ fontSize:'0.75rem', color:C.green, fontWeight:700 }}>{discount}% off</span>
        </div>
        <div style={{ marginTop:6 }}>
          <span style={{ fontSize:'0.68rem', padding:'2px 6px', borderRadius:2, background:condBadge[product.condition]?.[0], color:condBadge[product.condition]?.[1], fontWeight:700 }}>{product.condition}</span>
        </div>
      </div>
    </div>
  );
}

// ── Home Page ─────────────────────────────────────────────
function HomePage({ search, onView, wishlist, onWishlist }) {
  const [products, setProducts] = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [category, setCategory] = useState('All');
  const [condition,setCondition]= useState('All');
  const [maxPrice, setMaxPrice] = useState(2000);
  const [sort,     setSort]     = useState('default');

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (category !== 'All') params.category = category;
      if (condition !== 'All') params.condition = condition;
      if (maxPrice < 2000) params.maxPrice = maxPrice;
      if (search) params.search = search;
      if (sort !== 'default') params.sort = sort;
      const data = await productAPI.getAll(params);
      setProducts(data.products || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [category, condition, maxPrice, search, sort]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  return (
    <div style={{ maxWidth:1280, margin:'0 auto', padding:'16px 20px', display:'flex', gap:16, alignItems:'flex-start' }}>
      {/* Sidebar */}
      <div style={{ width:220, flexShrink:0, background:C.white, borderRadius:4, padding:16, boxShadow:'0 1px 4px rgba(0,0,0,0.08)' }}>
        <div style={{ fontWeight:800, fontSize:'0.95rem', marginBottom:14, paddingBottom:8, borderBottom:'1px solid '+C.gray100 }}>Filters</div>

        <div style={{ marginBottom:16 }}>
          <div style={{ fontWeight:700, fontSize:'0.78rem', marginBottom:8, color:C.gray600, textTransform:'uppercase', letterSpacing:0.5 }}>Category</div>
          {CATEGORIES.map(c => (
            <label key={c} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6, cursor:'pointer', fontSize:'0.85rem', color:category===c?C.blue:C.gray600, fontWeight:category===c?700:400 }}>
              <input type="radio" name="cat" checked={category===c} onChange={()=>setCategory(c)} style={{ accentColor:C.blue }} />{c}
            </label>
          ))}
        </div>

        <div style={{ marginBottom:16, paddingTop:12, borderTop:'1px solid '+C.gray100 }}>
          <div style={{ fontWeight:700, fontSize:'0.78rem', marginBottom:8, color:C.gray600, textTransform:'uppercase' }}>Max Price</div>
          <input type="range" min={100} max={2000} value={maxPrice} onChange={e=>setMaxPrice(+e.target.value)} style={{ width:'100%', accentColor:C.blue }} />
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:'0.78rem', color:C.gray400 }}>
            <span>₹100</span><span style={{ color:C.blue, fontWeight:700 }}>₹{maxPrice}</span>
          </div>
        </div>

        <div style={{ marginBottom:16, paddingTop:12, borderTop:'1px solid '+C.gray100 }}>
          <div style={{ fontWeight:700, fontSize:'0.78rem', marginBottom:8, color:C.gray600, textTransform:'uppercase' }}>Condition</div>
          {['All','Like New','Good','Fair'].map(c => (
            <label key={c} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6, cursor:'pointer', fontSize:'0.85rem', color:condition===c?C.blue:C.gray600, fontWeight:condition===c?700:400 }}>
              <input type="radio" name="cond" checked={condition===c} onChange={()=>setCondition(c)} style={{ accentColor:C.blue }} />{c}
            </label>
          ))}
        </div>

        <div style={{ paddingTop:12, borderTop:'1px solid '+C.gray100 }}>
          <div style={{ fontWeight:700, fontSize:'0.78rem', marginBottom:8, color:C.gray600, textTransform:'uppercase' }}>Sort By</div>
          <select value={sort} onChange={e=>setSort(e.target.value)} style={{ width:'100%', padding:'7px 8px', border:'1px solid '+C.gray200, borderRadius:4, fontSize:'0.83rem', fontFamily:'inherit' }}>
            <option value="default">Relevance</option>
            <option value="low">Price: Low to High</option>
            <option value="high">Price: High to Low</option>
            <option value="rating">Top Rated</option>
          </select>
        </div>
      </div>

      {/* Products */}
      <div style={{ flex:1 }}>
        <div style={{ background:`linear-gradient(135deg,${C.blue},${C.blueDark})`, borderRadius:4, padding:'20px 28px', marginBottom:16, color:'#fff', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div>
            <div style={{ fontSize:'1.3rem', fontWeight:900, marginBottom:4 }}>♻️ Thrift For Tomorrow</div>
            <div style={{ fontSize:'0.88rem', opacity:0.85 }}>Pre-loved fashion — up to 90% off</div>
          </div>
          <div style={{ textAlign:'right', fontSize:'0.82rem', opacity:0.8 }}>
            <div style={{ fontSize:'1.5rem', fontWeight:900 }}>{products.length}</div>
            <div>items found</div>
          </div>
        </div>

        {loading ? <Spinner /> : products.length === 0 ? (
          <div style={{ background:C.white, borderRadius:4, padding:'4rem', textAlign:'center', color:C.gray400 }}>
            <div style={{ fontSize:'3rem', marginBottom:12 }}>🔍</div>
            <div style={{ fontWeight:700 }}>No items found</div>
          </div>
        ) : (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:1, background:C.gray200 }}>
            {products.map((p,i) => <ProductCard key={p._id} product={p} index={i} onView={onView} onWishlist={onWishlist} wishlisted={wishlist.includes(p._id)} />)}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Product Detail Page ───────────────────────────────────
function ProductPage({ productId, onBack, onAddCart, onBuyNow, wishlist, onWishlist }) {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selSize, setSelSize] = useState('');
  const [qty,     setQty]     = useState(1);
  const [tab,     setTab]     = useState('desc');
  const [sizeErr, setSizeErr] = useState(false);

  useEffect(() => {
    setLoading(true);
    productAPI.getOne(productId)
      .then(d => setProduct(d.product))
      .finally(() => setLoading(false));
  }, [productId]);

  if (loading) return <Spinner />;
  if (!product) return <div style={{ padding:'2rem', textAlign:'center' }}>Product not found</div>;

  const discount = Math.round((1 - product.price / product.original) * 100);

  const handleCart = () => {
    if (!selSize) { setSizeErr(true); return; }
    setSizeErr(false);
    onAddCart({ ...product, selSize, qty });
  };

  const handleBuy = () => {
    if (!selSize) { setSizeErr(true); return; }
    setSizeErr(false);
    onBuyNow({ ...product, selSize, qty });
  };

  return (
    <div style={{ maxWidth:1280, margin:'0 auto', padding:'16px 20px' }}>
      <div style={{ fontSize:'0.78rem', color:C.gray400, marginBottom:12, display:'flex', gap:6 }}>
        <span onClick={onBack} style={{ cursor:'pointer', color:C.blue }}>Home</span>
        <span>›</span><span onClick={onBack} style={{ cursor:'pointer', color:C.blue }}>{product.category}</span>
        <span>›</span><span>{product.name}</span>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20, background:C.white, borderRadius:4, padding:24, boxShadow:'0 1px 4px rgba(0,0,0,0.08)', marginBottom:16 }}>
        {/* Image */}
        <div>
          <div style={{ background:cardBg[0], borderRadius:4, height:380, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'7rem', border:'1px solid '+C.gray200, position:'relative' }}>
            {product.images?.[0] ? <img src={product.images[0]} alt={product.name} style={{ width:'100%', height:'100%', objectFit:'cover', borderRadius:4 }} /> : '👗'}
            <button onClick={()=>onWishlist(product._id)} style={{ position:'absolute', top:12, right:12, background:C.white, border:'1px solid '+C.gray200, borderRadius:'50%', width:36, height:36, cursor:'pointer', fontSize:'1.1rem' }}>
              {wishlist.includes(product._id) ? '❤️' : '🤍'}
            </button>
          </div>
        </div>

        {/* Info */}
        <div>
          <div style={{ fontSize:'0.78rem', color:C.gray400, marginBottom:4 }}>{product.brand}</div>
          <h1 style={{ fontSize:'1.3rem', fontWeight:700, marginBottom:10, lineHeight:1.3 }}>{product.name}</h1>

          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:14, paddingBottom:14, borderBottom:'1px solid '+C.gray100 }}>
            <span style={{ background:C.green, color:'#fff', fontSize:'0.78rem', padding:'3px 8px', borderRadius:2, fontWeight:700 }}>{product.rating || 4.5} ★</span>
            <span style={{ color:C.gray400, fontSize:'0.82rem' }}>{product.numReviews || 0} ratings</span>
          </div>

          <div style={{ marginBottom:14 }}>
            <span style={{ fontSize:'1.8rem', fontWeight:900 }}>₹{product.price}</span>
            <span style={{ fontSize:'0.95rem', color:C.gray400, textDecoration:'line-through', marginLeft:10 }}>₹{product.original}</span>
            <span style={{ fontSize:'0.88rem', color:C.green, marginLeft:8, fontWeight:700 }}>{discount}% off</span>
            <div style={{ fontSize:'0.78rem', color:C.gray400, marginTop:2 }}>Inclusive of all taxes</div>
          </div>

          <div style={{ marginBottom:14 }}>
            <span style={{ fontSize:'0.82rem', fontWeight:600 }}>Condition: </span>
            <span style={{ fontSize:'0.8rem', padding:'3px 10px', borderRadius:2, background:condBadge[product.condition]?.[0], color:condBadge[product.condition]?.[1], fontWeight:700 }}>{product.condition}</span>
          </div>

          {/* Size */}
          <div style={{ marginBottom:16 }}>
            <div style={{ fontSize:'0.82rem', fontWeight:700, marginBottom:8 }}>
              Select Size {sizeErr && <span style={{ color:C.red, fontWeight:400 }}>— Please select a size</span>}
            </div>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
              {(product.sizes || []).map(s => (
                <button key={s} onClick={()=>{setSelSize(s);setSizeErr(false);}} style={{ padding:'8px 14px', border:selSize===s?'2px solid '+C.blue:'1.5px solid '+C.gray200, borderRadius:4, background:selSize===s?C.bluePale:C.white, color:selSize===s?C.blue:C.gray600, fontWeight:selSize===s?700:400, cursor:'pointer', fontFamily:'inherit', fontSize:'0.85rem' }}>{s}</button>
              ))}
            </div>
          </div>

          {/* Qty */}
          <div style={{ marginBottom:20, display:'flex', alignItems:'center', gap:12 }}>
            <span style={{ fontSize:'0.82rem', fontWeight:700 }}>Qty:</span>
            <div style={{ display:'flex', alignItems:'center', border:'1px solid '+C.gray200, borderRadius:4, overflow:'hidden' }}>
              <button onClick={()=>setQty(q=>Math.max(1,q-1))} style={{ width:32, height:32, border:'none', background:C.gray100, cursor:'pointer', fontWeight:700 }}>−</button>
              <span style={{ width:40, textAlign:'center', fontWeight:700 }}>{qty}</span>
              <button onClick={()=>setQty(q=>q+1)} style={{ width:32, height:32, border:'none', background:C.gray100, cursor:'pointer', fontWeight:700 }}>+</button>
            </div>
          </div>

          {/* Buttons */}
          <div style={{ display:'flex', gap:10, marginBottom:20 }}>
            <button onClick={handleCart} style={{ flex:1, padding:'14px', background:'#fff7ed', border:'1.5px solid '+C.orange, color:'#ea580c', borderRadius:4, fontWeight:800, cursor:'pointer', fontSize:'0.95rem', fontFamily:'inherit' }}>🛒 Add to Cart</button>
            <button onClick={handleBuy} style={{ flex:1, padding:'14px', background:C.orange, border:'none', color:C.white, borderRadius:4, fontWeight:800, cursor:'pointer', fontSize:'0.95rem', fontFamily:'inherit' }}>⚡ Buy Now</button>
          </div>

          {/* Seller info */}
          <div style={{ background:C.gray50, borderRadius:4, padding:12, border:'1px solid '+C.gray200 }}>
            <div style={{ fontSize:'0.8rem', marginBottom:4 }}>
              <span style={{ fontWeight:700 }}>Sold by:</span> {product.seller?.shopName || product.seller?.name}
              {product.seller?.isVerified && <span style={{ background:C.green, color:'#fff', fontSize:'0.68rem', padding:'2px 6px', borderRadius:2, marginLeft:8, fontWeight:700 }}>✓ Verified</span>}
            </div>
            <div style={{ fontSize:'0.78rem', color:C.gray400 }}>🚚 Shiprocket Delivery · ₹40 shipping</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ background:C.white, borderRadius:4, boxShadow:'0 1px 4px rgba(0,0,0,0.08)', overflow:'hidden' }}>
        <div style={{ display:'flex', borderBottom:'1px solid '+C.gray200 }}>
          {[['desc','Description'],['highlights','Highlights'],['reviews','Reviews']].map(([k,l]) => (
            <button key={k} onClick={()=>setTab(k)} style={{ padding:'14px 24px', border:'none', background:'none', cursor:'pointer', fontFamily:'inherit', fontSize:'0.88rem', fontWeight:tab===k?700:500, color:tab===k?C.blue:C.gray400, borderBottom:tab===k?'2px solid '+C.blue:'none' }}>{l}</button>
          ))}
        </div>
        <div style={{ padding:20 }}>
          {tab==='desc' && <p style={{ fontSize:'0.9rem', color:C.gray600, lineHeight:1.75 }}>{product.desc || 'No description available.'}</p>}
          {tab==='highlights' && <ul style={{ paddingLeft:20 }}>{(product.highlights||[]).map((h,i)=><li key={i} style={{ fontSize:'0.9rem', color:C.gray600, marginBottom:8 }}>{h}</li>)}</ul>}
          {tab==='reviews' && <p style={{ color:C.gray400 }}>No reviews yet.</p>}
        </div>
      </div>
    </div>
  );
}

// ── Checkout Flow ─────────────────────────────────────────
function CheckoutPage({ items, onBack, onConfirmed }) {
  const { user } = useAuth();
  const { payConfirmationFee } = useRazorpay();
  const [step, setStep]   = useState('address'); // address | payment | processing
  const [address, setAddr]= useState({ name: user?.name||'', phone:'', address:'', city:'', state:'Delhi', pincode:'' });
  const [method,  setMethod]= useState('upi');
  const [upiId,  setUpiId]= useState('');
  const [error,  setError]= useState('');

  const subtotal = items.reduce((s,x)=>s+(x.price*x.qty),0);

  const handlePlaceOrder = async () => {
    try {
      setStep('processing');
      // 1. Place order in backend
      const orderData = await orderAPI.place({
        productId: items[0]._id,
        size:      items[0].selSize,
        qty:       items[0].qty,
        address,
      });

      const orderId = orderData.order.orderId;

      // 2. Pay ₹12 confirmation fee via Razorpay
      await payConfirmationFee(orderId, {
        buyerName:   user?.name,
        buyerMobile: user?.mobile,
        onSuccess: () => onConfirmed(orderId),
        onError:   (err) => setError(err.message),
      });
    } catch (err) {
      setError(err.message);
      setStep('payment');
    }
  };

  if (step === 'processing') return (
    <div style={{ textAlign:'center', padding:'4rem' }}>
      <div style={{ fontSize:'3rem', marginBottom:16 }}>⏳</div>
      <div style={{ fontWeight:700, fontSize:'1.1rem' }}>Processing payment...</div>
    </div>
  );

  return (
    <div style={{ maxWidth:900, margin:'0 auto', padding:'20px' }}>
      <div style={{ display:'flex', gap:16, alignItems:'flex-start' }}>
        <div style={{ flex:1 }}>
          {step === 'address' && (
            <div style={{ background:C.white, borderRadius:4, boxShadow:'0 1px 4px rgba(0,0,0,0.08)', overflow:'hidden' }}>
              <div style={{ background:C.blue, padding:'14px 20px', color:'#fff', fontWeight:700 }}>📍 Delivery Address</div>
              <div style={{ padding:20, display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
                {[['Full Name','name'],['Phone','phone'],['Pincode','pincode'],['City','city']].map(([l,k])=>(
                  <div key={k}>
                    <label style={{ fontSize:'0.78rem', fontWeight:600, display:'block', marginBottom:4 }}>{l}</label>
                    <input value={address[k]} onChange={e=>setAddr(a=>({...a,[k]:e.target.value}))} style={{ width:'100%', padding:'9px 12px', border:'1px solid '+C.gray200, borderRadius:4, fontSize:'0.85rem', fontFamily:'inherit' }} />
                  </div>
                ))}
                <div style={{ gridColumn:'1/-1' }}>
                  <label style={{ fontSize:'0.78rem', fontWeight:600, display:'block', marginBottom:4 }}>Full Address</label>
                  <textarea value={address.address} onChange={e=>setAddr(a=>({...a,address:e.target.value}))} rows={2} style={{ width:'100%', padding:'9px 12px', border:'1px solid '+C.gray200, borderRadius:4, fontSize:'0.85rem', fontFamily:'inherit', resize:'none' }} />
                </div>
              </div>
              <div style={{ padding:'0 20px 20px' }}>
                <button onClick={()=>setStep('payment')} style={{ background:C.orange, color:C.white, border:'none', padding:'12px 28px', borderRadius:4, fontWeight:800, cursor:'pointer', fontFamily:'inherit', fontSize:'0.9rem' }}>Continue to Payment →</button>
              </div>
            </div>
          )}

          {step === 'payment' && (
            <div style={{ background:C.white, borderRadius:4, boxShadow:'0 1px 4px rgba(0,0,0,0.08)', overflow:'hidden' }}>
              <div style={{ background:C.blue, padding:'14px 20px', color:'#fff', fontWeight:700 }}>💳 Payment Method</div>
              {[{k:'upi',icon:'📱',label:'UPI'},{k:'card',icon:'💳',label:'Credit / Debit Card'},{k:'cod',icon:'💵',label:'Cash on Delivery'}].map(m=>(
                <div key={m.k} onClick={()=>setMethod(m.k)} style={{ padding:'16px 20px', borderBottom:'1px solid '+C.gray100, cursor:'pointer', background:method===m.k?C.bluePale:C.white }}>
                  <div style={{ display:'flex', gap:12, alignItems:'center' }}>
                    <input type="radio" checked={method===m.k} onChange={()=>setMethod(m.k)} style={{ accentColor:C.blue }} />
                    <span>{m.icon}</span>
                    <span style={{ fontWeight:method===m.k?700:500, color:method===m.k?C.blue:C.gray600 }}>{m.label}</span>
                  </div>
                  {method===m.k && m.k==='upi' && (
                    <div style={{ marginTop:10, marginLeft:28 }}>
                      <input value={upiId} onChange={e=>setUpiId(e.target.value)} placeholder="name@upi" style={{ padding:'8px 12px', border:'1px solid '+C.gray200, borderRadius:4, fontSize:'0.85rem', fontFamily:'inherit', width:280 }} />
                    </div>
                  )}
                </div>
              ))}
              {error && <div style={{ padding:'12px 20px', color:C.red, fontSize:'0.85rem' }}>⚠️ {error}</div>}
              <div style={{ padding:'16px 20px' }}>
                <button onClick={handlePlaceOrder} style={{ background:C.orange, color:C.white, border:'none', padding:'13px 32px', borderRadius:4, fontWeight:800, cursor:'pointer', fontFamily:'inherit', fontSize:'0.95rem' }}>
                  Pay ₹12 & Confirm Order →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Summary */}
        <div style={{ width:260, flexShrink:0, background:C.white, borderRadius:4, boxShadow:'0 1px 4px rgba(0,0,0,0.08)' }}>
          <div style={{ background:C.gray50, padding:'12px 16px', borderBottom:'1px solid '+C.gray200, fontWeight:700, fontSize:'0.88rem' }}>PRICE DETAILS</div>
          <div style={{ padding:16 }}>
            {items.map(item=>(
              <div key={item._id} style={{ display:'flex', gap:8, marginBottom:10, paddingBottom:10, borderBottom:'1px solid '+C.gray100 }}>
                <div style={{ flex:1, fontSize:'0.82rem', fontWeight:600 }}>{item.name} ×{item.qty}</div>
                <div style={{ fontWeight:700 }}>₹{item.price*item.qty}</div>
              </div>
            ))}
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6, fontSize:'0.85rem', color:C.gray600 }}>
              <span>Subtotal</span><span>₹{subtotal}</span>
            </div>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6, fontSize:'0.85rem', color:C.gray600 }}>
              <span>Delivery</span><span>₹40</span>
            </div>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6, fontSize:'0.85rem', color:C.blue, fontWeight:600 }}>
              <span>Confirmation Fee</span><span>₹12</span>
            </div>
            <div style={{ borderTop:'1px dashed '+C.gray200, marginTop:8, paddingTop:8, display:'flex', justifyContent:'space-between', fontWeight:800, fontSize:'1rem' }}>
              <span>Total</span><span>₹{subtotal+52}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Order Confirmed ───────────────────────────────────────
function OrderConfirmed({ orderId, onHome }) {
  const delivery = new Date(); delivery.setDate(delivery.getDate()+5);
  return (
    <div style={{ maxWidth:600, margin:'40px auto', padding:'20px', textAlign:'center' }}>
      <div style={{ background:C.white, borderRadius:8, boxShadow:'0 4px 20px rgba(0,0,0,0.08)', padding:'40px 32px' }}>
        <div style={{ fontSize:'4rem', marginBottom:16 }}>✅</div>
        <h1 style={{ fontSize:'1.5rem', fontWeight:900, color:C.green, marginBottom:8 }}>Order Confirmed!</h1>
        <p style={{ color:C.gray400, marginBottom:4 }}>Order ID: <strong style={{ color:'#111' }}>#{orderId}</strong></p>
        <p style={{ color:C.gray400, fontSize:'0.88rem', marginBottom:24 }}>Confirmation sent to your mobile</p>
        <div style={{ background:'#f0fdf4', border:'1px solid #bbf7d0', borderRadius:8, padding:16, marginBottom:24 }}>
          <div style={{ fontWeight:700, color:'#15803d', marginBottom:4 }}>🚚 Expected Delivery</div>
          <div style={{ fontSize:'1.1rem', fontWeight:800 }}>{delivery.toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long'})}</div>
          <div style={{ fontSize:'0.78rem', color:C.gray400, marginTop:4 }}>via Shiprocket</div>
        </div>
        <div style={{ display:'flex', gap:10, justifyContent:'center' }}>
          <button onClick={onHome} style={{ background:C.blue, color:C.white, border:'none', padding:'12px 28px', borderRadius:4, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>Continue Shopping</button>
          <button style={{ background:C.white, color:C.blue, border:'1.5px solid '+C.blue, padding:'12px 28px', borderRadius:4, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>My Orders</button>
        </div>
      </div>
    </div>
  );
}

// ── Login Modal ───────────────────────────────────────────
function LoginModal({ onClose }) {
  const { login, register } = useAuth();
  const [mode,     setMode]    = useState('login');
  const [userType, setType]    = useState('buyer');
  const [form,     setForm]    = useState({ name:'', mobile:'', password:'', shopName:'', upiId:'' });
  const [error,    setError]   = useState('');
  const [loading,  setLoading] = useState(false);

  const handle = async () => {
    setError(''); setLoading(true);
    try {
      if (mode === 'login') await login(form.mobile, form.password);
      else await register({ ...form, role: userType });
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.5)', zIndex:500, display:'flex', alignItems:'center', justifyContent:'center' }} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{ background:C.white, borderRadius:8, width:420, boxShadow:'0 20px 60px rgba(0,0,0,0.2)', overflow:'hidden' }}>
        <div style={{ background:C.blue, padding:'20px 24px', color:'#fff', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <span style={{ fontSize:'1.1rem', fontWeight:800 }}>{mode==='login'?'Login':'Create Account'}</span>
          <button onClick={onClose} style={{ background:'none', border:'none', color:'#fff', fontSize:'1.3rem', cursor:'pointer' }}>✕</button>
        </div>
        <div style={{ padding:24 }}>
          <div style={{ display:'flex', marginBottom:20, border:'1px solid '+C.gray200, borderRadius:4, overflow:'hidden' }}>
            {['buyer','seller'].map(t=>(
              <button key={t} onClick={()=>setType(t)} style={{ flex:1, padding:'10px', border:'none', background:userType===t?C.blue:C.white, color:userType===t?'#fff':C.gray600, fontWeight:700, cursor:'pointer', fontFamily:'inherit', fontSize:'0.88rem' }}>
                {t==='buyer'?'🛍️ Buyer':'🏪 Seller'}
              </button>
            ))}
          </div>
          {mode==='register' && <div style={{ marginBottom:14 }}>
            <label style={{ fontSize:'0.78rem', fontWeight:700, display:'block', marginBottom:5 }}>Full Name</label>
            <input value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} style={{ width:'100%', padding:'10px 12px', border:'1px solid '+C.gray200, borderRadius:4, fontSize:'0.88rem', fontFamily:'inherit' }} />
          </div>}
          <div style={{ marginBottom:14 }}>
            <label style={{ fontSize:'0.78rem', fontWeight:700, display:'block', marginBottom:5 }}>Mobile Number</label>
            <input value={form.mobile} onChange={e=>setForm(f=>({...f,mobile:e.target.value}))} placeholder="+91 98765 43210" style={{ width:'100%', padding:'10px 12px', border:'1px solid '+C.gray200, borderRadius:4, fontSize:'0.88rem', fontFamily:'inherit' }} />
          </div>
          <div style={{ marginBottom:14 }}>
            <label style={{ fontSize:'0.78rem', fontWeight:700, display:'block', marginBottom:5 }}>Password</label>
            <input type="password" value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))} style={{ width:'100%', padding:'10px 12px', border:'1px solid '+C.gray200, borderRadius:4, fontSize:'0.88rem', fontFamily:'inherit' }} />
          </div>
          {mode==='register' && userType==='seller' && <>
            <div style={{ marginBottom:14 }}>
              <label style={{ fontSize:'0.78rem', fontWeight:700, display:'block', marginBottom:5 }}>Shop Name</label>
              <input value={form.shopName} onChange={e=>setForm(f=>({...f,shopName:e.target.value}))} style={{ width:'100%', padding:'10px 12px', border:'1px solid '+C.gray200, borderRadius:4, fontSize:'0.88rem', fontFamily:'inherit' }} />
            </div>
            <div style={{ marginBottom:14 }}>
              <label style={{ fontSize:'0.78rem', fontWeight:700, display:'block', marginBottom:5 }}>UPI ID</label>
              <input value={form.upiId} onChange={e=>setForm(f=>({...f,upiId:e.target.value}))} placeholder="name@upi" style={{ width:'100%', padding:'10px 12px', border:'1px solid '+C.gray200, borderRadius:4, fontSize:'0.88rem', fontFamily:'inherit' }} />
            </div>
          </>}
          {error && <div style={{ color:C.red, fontSize:'0.85rem', marginBottom:12 }}>⚠️ {error}</div>}
          <button onClick={handle} disabled={loading} style={{ width:'100%', background:loading?C.gray400:C.blue, color:C.white, border:'none', padding:'13px', borderRadius:4, fontWeight:800, cursor:loading?'not-allowed':'pointer', fontFamily:'inherit', fontSize:'0.95rem', marginBottom:12 }}>
            {loading ? 'Please wait...' : mode==='login' ? 'Login →' : 'Create Account →'}
          </button>
          <div style={{ textAlign:'center', fontSize:'0.85rem', color:C.gray400 }}>
            {mode==='login'
              ? <span>New to TFT? <span onClick={()=>setMode('register')} style={{ color:C.blue, cursor:'pointer', fontWeight:700 }}>Create account</span></span>
              : <span>Have account? <span onClick={()=>setMode('login')} style={{ color:C.blue, cursor:'pointer', fontWeight:700 }}>Login</span></span>
            }
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Cart ──────────────────────────────────────────────────
function CartPage({ cart, onBack, onUpdateQty, onRemove, onCheckout }) {
  const subtotal = cart.reduce((s,x)=>s+(x.price*x.qty),0);
  if (!cart.length) return (
    <div style={{ textAlign:'center', padding:'4rem' }}>
      <div style={{ fontSize:'4rem', marginBottom:16 }}>🛒</div>
      <div style={{ fontWeight:700, fontSize:'1.2rem', marginBottom:8 }}>Cart is empty!</div>
      <button onClick={onBack} style={{ background:C.blue, color:C.white, border:'none', padding:'12px 28px', borderRadius:4, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>Shop Now</button>
    </div>
  );
  return (
    <div style={{ maxWidth:1000, margin:'0 auto', padding:'20px' }}>
      <h2 style={{ fontWeight:800, marginBottom:16 }}>My Cart ({cart.length} item{cart.length>1?'s':''})</h2>
      <div style={{ display:'flex', gap:16, alignItems:'flex-start' }}>
        <div style={{ flex:1 }}>
          {cart.map(item=>(
            <div key={item._id+item.selSize} style={{ background:C.white, borderRadius:4, boxShadow:'0 1px 4px rgba(0,0,0,0.06)', padding:16, marginBottom:10, display:'flex', gap:16 }}>
              <div style={{ width:88, height:88, background:cardBg[0], borderRadius:4, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'2.5rem', flexShrink:0 }}>👗</div>
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:700, marginBottom:4 }}>{item.name}</div>
                <div style={{ fontSize:'0.8rem', color:C.gray400, marginBottom:8 }}>Size: {item.selSize}</div>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                  <span style={{ fontWeight:800 }}>₹{item.price}</span>
                  <span style={{ fontSize:'0.78rem', color:C.gray400, textDecoration:'line-through' }}>₹{item.original}</span>
                </div>
              </div>
              <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-end', gap:12 }}>
                <div style={{ display:'flex', alignItems:'center', border:'1px solid '+C.gray200, borderRadius:4, overflow:'hidden' }}>
                  <button onClick={()=>item.qty>1?onUpdateQty(item._id,item.selSize,item.qty-1):onRemove(item._id,item.selSize)} style={{ width:30, height:30, border:'none', background:C.gray100, cursor:'pointer', fontWeight:700 }}>−</button>
                  <span style={{ width:36, textAlign:'center', fontWeight:700 }}>{item.qty}</span>
                  <button onClick={()=>onUpdateQty(item._id,item.selSize,item.qty+1)} style={{ width:30, height:30, border:'none', background:C.gray100, cursor:'pointer', fontWeight:700 }}>+</button>
                </div>
                <button onClick={()=>onRemove(item._id,item.selSize)} style={{ color:C.red, background:'none', border:'none', cursor:'pointer', fontSize:'0.8rem', fontFamily:'inherit' }}>Remove</button>
              </div>
            </div>
          ))}
        </div>
        <div style={{ width:260, flexShrink:0, background:C.white, borderRadius:4, boxShadow:'0 1px 4px rgba(0,0,0,0.06)' }}>
          <div style={{ background:C.gray50, padding:'12px 16px', borderBottom:'1px solid '+C.gray200, fontWeight:700, fontSize:'0.88rem' }}>PRICE DETAILS</div>
          <div style={{ padding:16 }}>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8, fontSize:'0.85rem', color:C.gray600 }}><span>Price</span><span>₹{subtotal}</span></div>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8, fontSize:'0.85rem', color:C.gray600 }}><span>Delivery</span><span>₹40</span></div>
            <div style={{ borderTop:'1px dashed '+C.gray200, marginTop:8, paddingTop:8, display:'flex', justifyContent:'space-between', fontWeight:800, fontSize:'1rem' }}><span>Total</span><span>₹{subtotal+40}</span></div>
            <div style={{ color:C.green, fontSize:'0.78rem', fontWeight:600, marginTop:6 }}>You save ₹{cart.reduce((s,x)=>s+((x.original-x.price)*x.qty),0)}!</div>
            <button onClick={onCheckout} style={{ width:'100%', marginTop:14, background:C.orange, color:C.white, border:'none', padding:'13px', borderRadius:4, fontWeight:800, cursor:'pointer', fontFamily:'inherit' }}>Place Order →</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────
function AppInner() {
  const { user, logout } = useAuth();
  const [page,    setPage]   = useState('home');
  const [selProd, setSelProd]= useState(null);
  const [cart,    setCart]   = useState([]);
  const [wishlist,setWish]   = useState([]);
  const [search,  setSearch] = useState('');
  const [buyItems,setBuyItems]= useState([]);
  const [orderId, setOrderId]= useState('');
  const [showLogin,setLogin] = useState(false);
  const [toast,   setToast]  = useState('');

  const showToast = (msg) => { setToast(msg); setTimeout(()=>setToast(''),2500); };

  const addToCart = (item) => {
    if (!user) { setLogin(true); return; }
    setCart(c=>{
      const e = c.find(x=>x._id===item._id&&x.selSize===item.selSize);
      if (e) return c.map(x=>x._id===item._id&&x.selSize===item.selSize?{...x,qty:x.qty+item.qty}:x);
      return [...c,item];
    });
    showToast('🛒 Added to cart!');
  };

  const buyNow = (item) => {
    if (!user) { setLogin(true); return; }
    setBuyItems([item]); setPage('checkout');
  };

  const toggleWish = (id) => {
    if (!user) { setLogin(true); return; }
    setWish(w=>w.includes(id)?w.filter(x=>x!==id):[...w,id]);
    showToast(wishlist.includes(id)?'Removed from wishlist':'❤️ Saved!');
  };

  const cartCount  = cart.reduce((s,x)=>s+x.qty,0);

  return (
    <div style={{ minHeight:'100vh', background:C.gray50, fontFamily:"'Segoe UI',system-ui,sans-serif" }}>
      <style>{'*{box-sizing:border-box;margin:0;padding:0;} input,select,textarea,button{font-family:inherit;}'}</style>

      <Header
        cartCount={cartCount} wishCount={wishlist.length}
        search={search} onSearch={setSearch}
        onCart={()=>setPage('cart')}
        onLogo={()=>{setPage('home');setSearch('');}}
        onLogin={()=>setLogin(true)}
        user={user} onLogout={()=>{logout();showToast('Logged out!');}}
      />

      <main>
        {page==='home'      && <HomePage search={search} onView={p=>{setSelProd(p);setPage('product');}} wishlist={wishlist} onWishlist={toggleWish} />}
        {page==='product'   && <ProductPage productId={selProd?._id} onBack={()=>setPage('home')} onAddCart={addToCart} onBuyNow={buyNow} wishlist={wishlist} onWishlist={toggleWish} />}
        {page==='cart'      && <CartPage cart={cart} onBack={()=>setPage('home')} onUpdateQty={(id,s,q)=>setCart(c=>c.map(x=>x._id===id&&x.selSize===s?{...x,qty:q}:x))} onRemove={(id,s)=>setCart(c=>c.filter(x=>!(x._id===id&&x.selSize===s)))} onCheckout={()=>{setBuyItems(cart);setPage('checkout');}} />}
        {page==='checkout'  && <CheckoutPage items={buyItems} onBack={()=>setPage('cart')} onConfirmed={(id)=>{setOrderId(id);setCart([]);setPage('confirmed');}} />}
        {page==='confirmed' && <OrderConfirmed orderId={orderId} onHome={()=>setPage('home')} />}
      </main>

      {showLogin && <LoginModal onClose={()=>setLogin(false)} />}
      <Toast msg={toast} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppInner />
    </AuthProvider>
  );
}
