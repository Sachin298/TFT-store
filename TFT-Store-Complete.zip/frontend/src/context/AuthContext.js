// src/context/AuthContext.js
import { createContext, useContext, useState, useEffect } from 'react';
import { authAPI } from '../api/api';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user,    setUser]    = useState(null);
  const [loading, setLoading] = useState(true);

  // Auto-login if token exists
  useEffect(() => {
    const token = localStorage.getItem('tft_token');
    if (token) {
      authAPI.me()
        .then(data => setUser(data.user))
        .catch(() => localStorage.removeItem('tft_token'))
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const login = async (mobile, password) => {
    const data = await authAPI.login({ mobile, password });
    localStorage.setItem('tft_token', data.token);
    setUser(data.user);
    return data.user;
  };

  const register = async (form) => {
    const data = await authAPI.register(form);
    localStorage.setItem('tft_token', data.token);
    setUser(data.user);
    return data.user;
  };

  const logout = () => {
    localStorage.removeItem('tft_token');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
