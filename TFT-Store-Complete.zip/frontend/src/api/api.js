// src/api/api.js
// ─── Base URL ────────────────────────────────────────────
const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// ─── Helper ──────────────────────────────────────────────
const request = async (url, method = 'GET', body = null, auth = false) => {
  const headers = { 'Content-Type': 'application/json' };
  if (auth) {
    const token = localStorage.getItem('tft_token');
    if (token) headers['Authorization'] = `Bearer ${token}`;
  }
  const res = await fetch(`${BASE_URL}${url}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : null,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Something went wrong');
  return data;
};

// ─── AUTH ─────────────────────────────────────────────────
export const authAPI = {
  register: (body) => request('/auth/register', 'POST', body),
  login:    (body) => request('/auth/login', 'POST', body),
  me:       ()     => request('/auth/me', 'GET', null, true),
  addAddress:  (body) => request('/auth/add-address', 'POST', body, true),
  toggleWishlist: (productId) => request(`/auth/wishlist/${productId}`, 'POST', null, true),
};

// ─── PRODUCTS ─────────────────────────────────────────────
export const productAPI = {
  getAll:  (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/products?${q}`);
  },
  getOne:  (id)  => request(`/products/${id}`),
  create:  (body) => request('/products', 'POST', body, true),
  update:  (id, body) => request(`/products/${id}`, 'PUT', body, true),
  remove:  (id)  => request(`/products/${id}`, 'DELETE', null, true),
};

// ─── ORDERS ───────────────────────────────────────────────
export const orderAPI = {
  place:     (body) => request('/orders', 'POST', body, true),
  myOrders:  ()     => request('/orders/my', 'GET', null, true),
  getOne:    (id)   => request(`/orders/${id}`, 'GET', null, true),
  updateStatus: (id, body) => request(`/orders/${id}/status`, 'PUT', body, true),
};

// ─── PAYMENT ──────────────────────────────────────────────
export const paymentAPI = {
  createConfirmFee:  (orderId) => request('/payment/create-confirmation-fee', 'POST', { orderId }, true),
  verifyConfirmFee:  (body)    => request('/payment/verify-confirmation-fee', 'POST', body, true),
  createProductPay:  (orderId) => request('/payment/create-product-payment', 'POST', { orderId }, true),
  verifyProductPay:  (body)    => request('/payment/verify-product-payment', 'POST', body, true),
};

// ─── SELLER ───────────────────────────────────────────────
export const sellerAPI = {
  dashboard: () => request('/seller/dashboard', 'GET', null, true),
  orders:    () => request('/seller/orders',    'GET', null, true),
  products:  () => request('/seller/products',  'GET', null, true),
  earnings:  () => request('/seller/earnings',  'GET', null, true),
};
